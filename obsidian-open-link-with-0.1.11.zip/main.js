'use strict';

var obsidian = require('obsidian');
var child_process = require('child_process');
var fs = require('fs');
var path = require('path');
var os = require('os');

function _interopNamespace(e) {
    if (e && e.__esModule) return e;
    var n = Object.create(null);
    if (e) {
        Object.keys(e).forEach(function (k) {
            if (k !== 'default') {
                var d = Object.getOwnPropertyDescriptor(e, k);
                Object.defineProperty(n, k, d.get ? d : {
                    enumerable: true,
                    get: function () { return e[k]; }
                });
            }
        });
    }
    n["default"] = e;
    return Object.freeze(n);
}

var path__namespace = /*#__PURE__*/_interopNamespace(path);

/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

typeof SuppressedError === "function" ? SuppressedError : function (error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};

var Rule;
(function (Rule) {
    class _Rule {
        constructor(items, value) {
            this.items = items;
            this.value = value;
        }
    }
    Rule._Rule = _Rule;
    class Empty extends _Rule {
        constructor(value) {
            super([], value);
        }
    }
    Rule.Empty = Empty;
    class Exact extends _Rule {
    }
    Rule.Exact = Exact;
    class Contains extends _Rule {
    }
    Rule.Contains = Contains;
    class NotExact extends _Rule {
    }
    Rule.NotExact = NotExact;
    class NotContains extends _Rule {
    }
    Rule.NotContains = NotContains;
})(Rule || (Rule = {}));
var Platform;
(function (Platform) {
    Platform["Unknown"] = "unknown";
    Platform["Linux"] = "linux";
    Platform["Mac"] = "mac";
    Platform["Win"] = "win";
})(Platform || (Platform = {}));
var Modifier;
(function (Modifier) {
    Modifier["Alt"] = "alt";
    Modifier["Ctrl"] = "ctrl";
    Modifier["Meta"] = "meta";
    Modifier["Shift"] = "shift";
})(Modifier || (Modifier = {}));
var MouseButton;
(function (MouseButton) {
    MouseButton[MouseButton["Main"] = 0] = "Main";
    MouseButton[MouseButton["Auxiliary"] = 1] = "Auxiliary";
    MouseButton[MouseButton["Secondary"] = 2] = "Secondary";
    MouseButton[MouseButton["Fourth"] = 3] = "Fourth";
    MouseButton[MouseButton["Fifth"] = 4] = "Fifth";
})(MouseButton || (MouseButton = {}));
var ViewMode;
(function (ViewMode) {
    ViewMode[ViewMode["LAST"] = 0] = "LAST";
    ViewMode[ViewMode["NEW"] = 1] = "NEW";
})(ViewMode || (ViewMode = {}));

class RulesChecker {
    constructor(_rules = []) {
        this._rules = _rules;
    }
    addRule(rule) {
        this._rules.push(rule);
    }
    check(input, options = {}) {
        var _a;
        const matched = [];
        for (const rule of this._rules) {
            if (((_a = options === null || options === void 0 ? void 0 : options.breakOnFirstSuccess) !== null && _a !== void 0 ? _a : false) &&
                matched.length > 0) {
                break;
            }
            const { items } = rule;
            if (rule instanceof Rule.Exact || rule instanceof Rule.NotExact) {
                let ok = false;
                if (items.length === input.length) {
                    ok = items.every((item) => input.contains(item));
                }
                if (rule instanceof Rule.Exact ? ok : !ok) {
                    matched.push(rule.value);
                }
            }
            else if (rule instanceof Rule.Contains ||
                rule instanceof Rule.NotContains) {
                let ok = false;
                if (items.length <= input.length) {
                    ok = items.every((item) => input.contains(item));
                }
                if (rule instanceof Rule.Contains ? ok : !ok) {
                    matched.push(rule.value);
                }
            }
            else if (rule instanceof Rule.Empty) {
                if (input.length === 0) {
                    matched.push(rule.value);
                }
            }
            else {
                throw new TypeError(`invalid rule type: ${rule.constructor.name}`);
            }
        }
        return matched;
    }
}
class WindowUtils {
    constructor(_plugin) {
        this._plugin = _plugin;
        this._windows = {};
    }
    initWindow(win) {
        win.mid = genRandomStr(8);
        return win;
    }
    registerWindow(win) {
        if (typeof win.mid === 'undefined') {
            win = this.initWindow(win);
            if (this._plugin.settings.enableLog) {
                log('info', 'window registered', { mid: win.mid, window: win });
            }
            this._windows[win.mid] = win;
        }
    }
    unregisterWindow(win) {
        if (typeof win.mid !== 'undefined') {
            delete this._windows[win.mid];
            log('info', 'window unregistered', { mid: win.mid, window: win });
            win.mid = undefined;
        }
    }
    getRecords() {
        return this._windows;
    }
    getWindow(mid) {
        return this._windows[mid];
    }
}
const getPlatform = () => {
    const platform = window.navigator.platform;
    switch (platform.slice(0, 3)) {
        case 'Mac':
            return Platform.Mac;
        case 'Win':
            return Platform.Win;
        default:
            return Platform.Linux;
    }
};
const getModifiersFromMouseEvt = (evt) => {
    const { altKey, ctrlKey, metaKey, shiftKey } = evt;
    const mods = [];
    if (altKey) {
        mods.push(Modifier.Alt);
    }
    if (ctrlKey) {
        mods.push(Modifier.Ctrl);
    }
    if (metaKey) {
        mods.push(Modifier.Meta);
    }
    if (shiftKey) {
        mods.push(Modifier.Shift);
    }
    return mods;
};
const genRandomChar = (radix) => {
    return Math.floor(Math.random() * radix)
        .toString(radix)
        .toLocaleUpperCase();
};
const genRandomStr = (len) => {
    const id = [];
    for (const _ of ' '.repeat(len)) {
        id.push(genRandomChar(36));
    }
    return id.join('');
};
const getValidHttpURL = (url) => {
    if (typeof url === 'undefined') {
        return null;
    }
    else if (url instanceof URL) {
        return ['http:', 'https:'].indexOf(url.protocol) != -1
            ? url.toString()
            : null;
    }
    else {
        try {
            return getValidHttpURL(new URL(url));
        }
        catch (TypeError) {
            return null;
        }
    }
};
const getValidModifiers = (platform) => {
    if (platform === Platform.Unknown) {
        return ['none'];
    }
    else {
        return ['none', 'ctrl', 'meta', 'alt', 'shift'];
    }
};
const log = (level, title, message) => {
    let logger;
    if (level === 'warn') {
        logger = console.warn;
    }
    else if (level === 'error') {
        logger = console.error;
    }
    else {
        logger = console.info;
    }
    logger(`[open-link-with] ${title}`, message);
};

const checkClickable = (el) => {
    const res = {
        is_clickable: false,
        url: null,
        paneType: undefined,
        modifier_rules: [],
    };
    const CTRL = obsidian.Platform.isMacOS ? Modifier.Meta : Modifier.Ctrl;
    const ALT = Modifier.Alt;
    const SHIFT = Modifier.Shift;
    //  - links in read mode
    if (el.classList.contains('external-link')) {
        res.is_clickable = true;
        res.url = el.getAttribute('href');
        res.modifier_rules = [
            new Rule.Exact([CTRL], 'tab'),
            new Rule.Exact([CTRL, ALT], 'split'),
            new Rule.Exact([CTRL, SHIFT], 'tab'),
            new Rule.Exact([CTRL, ALT, SHIFT], 'window'),
            new Rule.Contains([], undefined), // fallback
        ];
    }
    //  -
    if (el.classList.contains('clickable-icon')) ;
    //  - links in live preview mode
    if (el.classList.contains('cm-underline')) {
        res.is_clickable = null;
        // res.url = // determined by `window._builtInOpen`
        res.modifier_rules = [
            new Rule.Empty(undefined),
            new Rule.Exact([CTRL], 'tab'),
            new Rule.Exact([CTRL, ALT], 'split'),
            new Rule.Exact([CTRL, SHIFT], 'tab'),
            new Rule.Exact([CTRL, ALT, SHIFT], 'window'),
        ];
    }
    //  - links in edit mode
    if (el.classList.contains('cm-url')) {
        res.is_clickable = null;
        // res.url = // determined by `window._builtInOpen`
        res.modifier_rules = [
            new Rule.Exact([CTRL], undefined),
            new Rule.Exact([CTRL, ALT], 'split'),
            new Rule.Exact([CTRL, SHIFT], 'tab'),
            new Rule.Exact([CTRL, ALT, SHIFT], 'window'),
        ];
    }
    // - links in community plugins' readme
    if (res.is_clickable === false && el.tagName === 'A') {
        let p = el;
        while (p.tagName !== 'BODY') {
            if (p.classList.contains('internal-link')) {
                break;
            }
            else if (p.classList.contains('community-modal-info')) {
                res.is_clickable = true;
                res.url = el.getAttribute('href');
                res.paneType =
                    el.getAttribute('target') === '_blank'
                        ? 'window'
                        : res.paneType;
                break;
            }
            p = p.parentElement;
        }
    }
    return res;
};
class LocalDocClickHandler {
    constructor(clickUilts) {
        this.clickUilts = clickUilts;
        this._enabled = false;
        this._handleAuxClick = false;
    }
    get enabled() {
        return this._enabled;
    }
    set enabled(val) {
        this._enabled = val;
    }
    get handleAuxClick() {
        return this._handleAuxClick;
    }
    set handleAuxClick(val) {
        this._handleAuxClick = val;
    }
    call(evt) {
        const win = evt.doc.win;
        if (typeof win.mid !== 'undefined' && this._enabled) {
            this._handler(evt);
        }
    }
    _handler(evt) {
        const el = evt.target;
        const win = evt.doc.win;
        const modifiers = getModifiersFromMouseEvt(evt);
        const clickable = checkClickable(el);
        let fire = true;
        let url = clickable.url;
        if (win.oolwPendingUrls.length > 0) {
            // win.oolwPendingUrls for getting correct urls from default open API
            url = win.oolwPendingUrls.pop();
        }
        else {
            // for urls could be invalid (inner links)
            if (url !== null && !getValidHttpURL(url)) {
                fire = false;
                win._builtInOpen(url);
            }
        }
        if (clickable.is_clickable === false && url === null) {
            return false;
        }
        let { paneType } = clickable;
        if (url === null) {
            fire = false;
        }
        if (clickable.modifier_rules.length > 0) {
            const checker = new RulesChecker(clickable.modifier_rules);
            const matched = checker.check(modifiers, {
                breakOnFirstSuccess: true,
            });
            if (matched.length == 0) {
                if (clickable.is_clickable) ;
                else {
                    fire = false;
                }
            }
            else if (matched[0] === false) {
                fire = false;
            }
            else if (typeof matched[0] === 'undefined') {
                paneType = undefined;
            }
            else {
                paneType = matched[0];
            }
        }
        // apply on middle click only
        if (this.handleAuxClick && evt.button === 2) {
            fire = false;
        }
        evt.preventDefault();
        if (this.clickUilts._plugin.settings.enableLog) {
            log('info', 'click event (LocalDocClickHandler)', {
                is_aux: this.handleAuxClick,
                clickable,
                url,
                modifiers,
                btn: evt.button,
            });
        }
        if (!fire) {
            return false;
        }
        const dummy = evt.doc.createElement('a');
        const cid = genRandomStr(4);
        dummy.setAttribute('href', url);
        dummy.setAttribute('oolw-pane-type', paneType || '');
        dummy.setAttribute('oolw-cid', cid);
        dummy.addClass('oolw-external-link-dummy');
        evt.doc.body.appendChild(dummy);
        //
        const e_cp = new MouseEvent(evt.type, evt);
        dummy.dispatchEvent(e_cp);
        dummy.remove();
    }
}
class ClickUtils {
    constructor(_plugin, _windowUtils) {
        this._plugin = _plugin;
        this._windowUtils = _windowUtils;
        this._localHandlers = {};
    }
    initDocClickHandler(win) {
        if (!this._localHandlers.hasOwnProperty(win.mid)) {
            const clickHandler = new LocalDocClickHandler(this);
            clickHandler.enabled = true;
            const auxclickHandler = new LocalDocClickHandler(this);
            auxclickHandler.enabled = true;
            auxclickHandler.handleAuxClick = true;
            //
            win.document.addEventListener('click', clickHandler.call.bind(clickHandler));
            win.document.addEventListener('auxclick', auxclickHandler.call.bind(auxclickHandler));
            //
            this._localHandlers[win.mid] = {
                click: clickHandler,
                auxclick: auxclickHandler,
            };
        }
    }
    removeDocClickHandler(win) {
        if (this._localHandlers.hasOwnProperty(win.mid)) {
            const handlers = this._localHandlers[win.mid];
            handlers.click.enabled = false;
            handlers.auxclick.enabled = false;
            win.document.removeEventListener('click', handlers.click.call.bind(handlers.click));
            win.document.removeEventListener('auxclick', handlers.auxclick.call.bind(handlers.auxclick));
            delete this._localHandlers[win.mid];
        }
    }
    overrideDefaultWindowOpen(win, enabled = true) {
        if (enabled && typeof win._builtInOpen === 'undefined') {
            win._builtInOpen = win.open;
            win.oolwCIDs = [];
            win.oolwPendingUrls = [];
            win.open = (url, target, feature) => {
                if (this._plugin.settings.enableLog) {
                    log('info', 'Obsidian.window._builtInOpen', {
                        url,
                        target,
                        feature,
                    });
                }
                const validUrl = getValidHttpURL(url);
                if (validUrl === null) {
                    return win._builtInOpen(url, target, feature);
                }
                else {
                    win.oolwPendingUrls.push(validUrl);
                    return win;
                }
            };
        }
        else if (!enabled && typeof win._builtInOpen !== 'undefined') {
            win.open = win._builtInOpen;
            delete win._builtInOpen;
            delete win.oolwCIDs;
            delete win.oolwPendingUrls;
        }
    }
}

const BROWSER_SYSTEM = {
    val: '_system',
    display: 'system-default',
};
const BROWSER_GLOBAL = {
    val: '_global',
    display: 'global',
};
const BROWSER_IN_APP = {
    val: '_in_app',
    display: 'in-app view (always new split)',
};
const BROWSER_IN_APP_LAST = {
    val: '_in_app_last',
    display: 'in-app view',
};
const BROWSER_WEB_VIEWER = {
    val: '_web_viewer',
    display: 'web viewer (Obsidian 1.9+)',
};
const _isExecutableExist = (fp) => __awaiter(void 0, void 0, void 0, function* () {
    return fs.existsSync(fp);
});
const _isExecutableAvailable = (exec) => __awaiter(void 0, void 0, void 0, function* () {
    return child_process.spawnSync('which', [exec]).status === 0;
});
const PRESET_BROWSERS = {
    safari: {
        darwin: {
            sysCmd: 'open',
            sysArgs: ['-a'],
            cmd: 'safari',
            optional: {},
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () {
                return true;
            }),
        },
    },
    firefox: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Firefox.app', 'Contents', 'MacOS', 'firefox'),
            optional: {
                private: {
                    args: ['--private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        linux: {
            cmd: 'firefox',
            optional: {
                private: {
                    args: ['--private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableAvailable(b.cmd); }),
        },
        win32: {
            cmd: path__namespace.join('c:', 'Program Files', 'Mozilla Firefox', 'firefox.exe'),
            optional: {
                private: {
                    args: ['--private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
    },
    chrome: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Google Chrome.app', 'Contents', 'MacOS', 'Google Chrome'),
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        linux: {
            cmd: 'google-chrome',
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableAvailable(b.cmd); }),
        },
        win32: {
            cmd: path__namespace.join('c:', 'Program Files (x86)', 'Google', 'Chrome', 'Application', 'chrome.exe'),
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
    },
    chromium: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Chromium.app', 'Contents', 'MacOS', 'Chromium'),
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        linux: {
            cmd: 'chromium-browser',
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableAvailable(b.cmd); }),
        },
    },
    edge: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Microsoft Edge.app', 'Contents', 'MacOS', 'Microsoft Edge'),
            optional: {
                private: {
                    args: ['-inprivate'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        win32: {
            cmd: path__namespace.join('c:', 'Program Files (x86)', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
            optional: {
                private: {
                    args: ['-inprivate'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
    },
    brave: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Brave Browser.app', 'Contents', 'MacOS', 'Brave Browser'),
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        linux: {
            cmd: 'brave-browser',
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableAvailable(b.cmd); }),
        },
        win32: {
            cmd: path__namespace.join('c:', 'Program Files', 'BraveSoftware', 'Brave-Browser', 'Application', 'brave.exe'),
            optional: {
                private: {
                    args: ['-incognito'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
    },
    waterfox: {
        darwin: {
            cmd: path__namespace.join('/Applications', 'Waterfox.app', 'Contents', 'MacOS', 'Waterfox'),
            optional: {
                private: {
                    args: ['-private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
        linux: {
            cmd: 'waterfox',
            optional: {
                private: {
                    args: ['-private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableAvailable(b.cmd); }),
        },
        win32: {
            cmd: path__namespace.join('c:', 'Program Files', 'Waterfox', 'waterfox.exe'),
            optional: {
                private: {
                    args: ['-private-window'],
                },
            },
            isAvailable: (b) => __awaiter(void 0, void 0, void 0, function* () { return _isExecutableExist(b.cmd); }),
        },
    },
};
const MODIFIER_TEXT_FALLBACK = {
    none: 'None',
    meta: 'Meta',
    alt: 'Alt',
    ctrl: 'Ctrl',
    shift: 'Shift',
};
const MODIFIER_TEXT = {
    mac: {
        meta: 'Cmd⌘',
        alt: 'Option⌥',
        ctrl: 'Control⌃',
        shift: 'Shift⇧',
    },
    win: {
        meta: 'Windows',
    },
};

const openWith = (url, cmd, options = {}) => __awaiter(void 0, void 0, void 0, function* () {
    const _spawn = (args) => __awaiter(void 0, void 0, void 0, function* () {
        return new Promise((res) => {
            var _a, _b;
            const _args = [...args];
            const reg = RegExp(/^[^"|'](.+)(?<!\\)(\ ){1}/);
            const match = reg.exec(_args[0]);
            if (match !== null) {
                // TODO: may have potential issues
                _args[0] = `"${_args[0]}"`;
            }
            reg.exec(_args[0]);
            if ((_a = options === null || options === void 0 ? void 0 : options.enableLog) !== null && _a !== void 0 ? _a : false) {
                log('info', 'opening', _args.join(' '));
            }
            const child = child_process.spawn(_args[0], args.slice(1), {
                stdio: 'ignore',
                shell: true,
            });
            child.on('exit', (code) => {
                res(code);
            });
            setTimeout(() => {
                res(0);
            }, (_b = options === null || options === void 0 ? void 0 : options.timeout) !== null && _b !== void 0 ? _b : 250);
        });
    });
    const target = '$TARGET_URL';
    let match = false;
    const _cmd = cmd.map((arg) => {
        const idx = arg.indexOf(target);
        if (idx !== -1) {
            match = true;
            return (arg.slice(0, idx) +
                encodeURIComponent(url) +
                arg.slice(idx + target.length));
        }
        else {
            return arg;
        }
    });
    if (!match) {
        _cmd.push(url);
    }
    return yield _spawn(_cmd);
});

class Browser {
    constructor(name, defaultCMD) {
        this.name = name;
        this.getExecCommands = (platform) => {
            var _a, _b;
            const res = {};
            let bp = this.profiles[platform];
            for (const pvt of [0, 1]) {
                const cmds = [];
                let bpBase;
                if (pvt) {
                    if (!((_a = bp === null || bp === void 0 ? void 0 : bp.optional) === null || _a === void 0 ? void 0 : _a.private)) {
                        continue;
                    }
                    bpBase = Object.assign(Object.assign({}, bp), ((_b = bp.optional.private) !== null && _b !== void 0 ? _b : {}));
                }
                else {
                    bpBase = bp;
                }
                if (bpBase.sysCmd) {
                    cmds.push(bpBase.sysCmd);
                }
                if (bpBase.sysArgs) {
                    bpBase.sysArgs.forEach((arg) => cmds.push(arg));
                }
                cmds.push(bpBase.cmd);
                if (bpBase.args) {
                    bpBase.args.forEach((arg) => cmds.push(arg));
                }
                if (pvt) {
                    res.private = cmds;
                }
                else {
                    res.main = cmds;
                }
            }
            return res;
        };
        this.name = name;
        this.profiles = defaultCMD;
    }
}
const getPresetBrowsers = () => {
    const presets = [];
    for (const name of Object.keys(PRESET_BROWSERS)) {
        presets.push(new Browser(name, PRESET_BROWSERS[name]));
    }
    return presets;
};
class ProfileMgr {
    constructor() {
        this.loadValidPresetBrowsers = () => __awaiter(this, void 0, void 0, function* () {
            this._preset_browser = [];
            const presets = getPresetBrowsers();
            const os$1 = os.platform();
            presets.forEach((browser) => __awaiter(this, void 0, void 0, function* () {
                const { profiles, name } = browser;
                let app = profiles[os$1];
                if (typeof app !== 'undefined' &&
                    app.isAvailable &&
                    (yield app.isAvailable(app))) {
                    this._preset_browser.push(browser);
                }
            }));
        });
        this.getBrowsers = () => {
            return [...this._preset_browser, ...this._browsers];
        };
        this.getBrowsersCMD = (custom) => {
            const res = {};
            this.getBrowsers().forEach((browser) => {
                const cmds = browser.getExecCommands(os.platform());
                res[browser.name] = cmds.main;
                if (typeof cmds.private !== 'undefined') {
                    res[browser.name + '-private'] = cmds.private;
                }
            });
            return Object.assign(Object.assign({}, res), custom);
        };
        this._browsers = [];
    }
}

class InAppView extends obsidian.ItemView {
    constructor(leaf, url) {
        super(leaf);
        this.url = url;
        this.icon = 'link';
        this.title = new URL(url).host;
        // TODO: remove this after tab title issue is fixed
        this.leaf.setPinned(true);
        setTimeout(() => {
            this.leaf.setPinned(false);
        }, 10);
    }
    onOpen() {
        return __awaiter(this, void 0, void 0, function* () {
            const frame_styles = [
                'height: 100%',
                'width: 100%',
                'background-color: white', // for pages with no background
            ];
            this.frame = document.createElement('iframe');
            this.frame.setAttr('style', frame_styles.join('; '));
            this.frame.setAttr('src', this.url);
            this.containerEl.children[1].appendChild(this.frame);
        });
    }
    getDisplayText() {
        return this.title;
    }
    getViewType() {
        return 'OOLW::InAppView';
    }
}
class WebViewerView extends obsidian.ItemView {
    constructor(leaf, url) {
        super(leaf);
        this.url = url;
        this.icon = 'popup-open';
        this.title = new URL(url).host;
        // TODO: remove this after tab title issue is fixed
        this.leaf.setPinned(true);
        setTimeout(() => {
            this.leaf.setPinned(false);
        }, 10);
    }
    onOpen() {
        var _a, _b, _c, _d;
        return __awaiter(this, void 0, void 0, function* () {
            // Try to use Obsidian's built-in web viewer if available (1.9+)
            try {
                // Check if the browser view type is available in Obsidian 1.9+
                const app = this.app;
                if (app.viewRegistry && app.viewRegistry.viewByType &&
                    app.viewRegistry.viewByType['browser']) {
                    // Use the built-in browser view if available
                    const browserLeaf = this.app.workspace.getLeaf('tab');
                    yield browserLeaf.setViewState({
                        type: 'browser',
                        state: { url: this.url }
                    });
                    // If successful, switch to that leaf and close this one
                    this.app.workspace.setActiveLeaf(browserLeaf);
                    this.leaf.detach();
                    return;
                }
            }
            catch (error) {
                // Safely check for logging settings
                try {
                    const app = this.app;
                    if ((_d = (_c = (_b = (_a = app.plugins) === null || _a === void 0 ? void 0 : _a.plugins) === null || _b === void 0 ? void 0 : _b['open-link-with']) === null || _c === void 0 ? void 0 : _c.settings) === null || _d === void 0 ? void 0 : _d.enableLog) {
                        log('info', 'Built-in browser view not available, using enhanced iframe fallback', error);
                    }
                }
                catch (logError) {
                    // Ignore logging errors
                }
            }
            // Enhanced iframe fallback with better browser-like features
            const frame_styles = [
                'height: 100%',
                'width: 100%',
                'background-color: white',
                'border: none',
            ];
            const frame = document.createElement('iframe');
            frame.setAttr('style', frame_styles.join('; '));
            frame.setAttr('src', this.url);
            // Enhanced security and features for web viewer
            frame.setAttr('sandbox', 'allow-same-origin allow-scripts allow-popups allow-forms allow-popups-to-escape-sandbox allow-top-navigation');
            frame.setAttr('allow', 'fullscreen; autoplay; encrypted-media');
            this.containerEl.children[1].appendChild(frame);
        });
    }
    getDisplayText() {
        return this.title;
    }
    getViewType() {
        return 'OOLW::WebViewerView';
    }
}
class ViewMgr {
    constructor(plugin) {
        this.plugin = plugin;
    }
    _getLeafId(leaf) {
        var _a;
        return (_a = leaf['id']) !== null && _a !== void 0 ? _a : '';
    }
    _validRecords() {
        var _a;
        const records = (_a = this.plugin.settings.inAppViewRec) !== null && _a !== void 0 ? _a : [];
        const validRec = [];
        try {
            for (const rec of records) {
                if (this.plugin.app.workspace.getLeafById(rec.leafId) !== null) {
                    validRec.push(rec);
                }
            }
        }
        catch (err) {
            if (this.plugin.settings.enableLog) {
                log('error', 'failed to restore views', `${err}`);
            }
        }
        return validRec;
    }
    createView(url, mode, options = {}) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            const getNewLeafId = () => {
                const newLeaf = typeof options.paneType === 'undefined'
                    ? false
                    : options.paneType;
                const leaf = this.plugin.app.workspace.getLeaf(newLeaf === false ? 'tab' : newLeaf // TODO: missing navigation; using tab for now
                );
                return this._getLeafId(leaf);
            };
            let id = undefined;
            // TODO: more robust open behaviors
            if (typeof options.paneType !== 'undefined' || mode === ViewMode.NEW) {
                id = getNewLeafId();
            }
            else {
                const viewRec = this._validRecords();
                let rec = (_a = viewRec.find(({ mode }) => mode === ViewMode.LAST)) !== null && _a !== void 0 ? _a : viewRec.find(({ mode }) => mode === ViewMode.NEW);
                id = (_b = rec === null || rec === void 0 ? void 0 : rec.leafId) !== null && _b !== void 0 ? _b : getNewLeafId();
            }
            return yield this.updateView(id, url, mode, options === null || options === void 0 ? void 0 : options.focus, options === null || options === void 0 ? void 0 : options.useWebViewer);
        });
    }
    updateView(leafId, url, mode, focus = true, useWebViewer = false) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const leaf = this.plugin.app.workspace.getLeafById(leafId);
            if (leaf === null) {
                return null;
            }
            else {
                const view = useWebViewer ? new WebViewerView(leaf, url) : new InAppView(leaf, url);
                yield leaf.open(view);
                const rec = this.plugin.settings.inAppViewRec.find((rec) => rec.leafId === leafId);
                if (typeof rec !== 'undefined') {
                    rec.url = url;
                    // TODO:
                    rec.mode = (_a = rec.mode) !== null && _a !== void 0 ? _a : mode;
                }
                else {
                    this.plugin.settings.inAppViewRec.unshift({
                        leafId,
                        url,
                        mode,
                    });
                }
                yield this.plugin.saveSettings();
                // this.plugin.app.workspace.setActiveLeaf(leaf, { focus }) // TODO: option `focus` is not working (cliVer == 1.1.9)
                if (focus) {
                    this.plugin.app.workspace.setActiveLeaf(leaf);
                }
                return leafId;
            }
        });
    }
    createWebViewerView(url, mode, options = {}) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield this.createView(url, mode, Object.assign(Object.assign({}, options), { useWebViewer: true }));
        });
    }
    restoreView() {
        return __awaiter(this, void 0, void 0, function* () {
            const viewRec = this._validRecords();
            const restored = [];
            for (const rec of viewRec) {
                if ((yield this.updateView(rec.leafId, rec.url, rec.mode, false)) !== null) {
                    restored.push(rec);
                }
            }
            this.plugin.settings.inAppViewRec = restored;
            yield this.plugin.saveSettings();
        });
    }
}

const DEFAULT_SETTINGS = {
    selected: BROWSER_SYSTEM.val,
    custom: {},
    modifierBindings: [],
    enableLog: false,
    timeout: 500,
    inAppViewRec: [],
};
class OpenLinkPlugin extends obsidian.Plugin {
    onload() {
        return __awaiter(this, void 0, void 0, function* () {
            this._viewmgr = new ViewMgr(this);
            yield this.loadSettings();
            this.profiles = new ProfileMgr();
            yield this.profiles.loadValidPresetBrowsers();
            const extLinkClick = (evt, validClassName, options = {}) => __awaiter(this, void 0, void 0, function* () {
                var _a;
                const win = activeWindow;
                const el = evt.target;
                if (!el.classList.contains(validClassName)) {
                    return;
                }
                const oolwCID = el.getAttribute('oolw-cid');
                if (typeof oolwCID !== 'undefined') {
                    if (win.oolwCIDs.contains(oolwCID)) {
                        return; // FIXME: prevent double click
                    }
                    else {
                        win.oolwCIDs.push(oolwCID);
                        setTimeout(() => {
                            win.oolwCIDs.remove(oolwCID);
                        }, 10);
                    }
                }
                const { button, altKey, ctrlKey, metaKey, shiftKey } = evt;
                let modifier = 'none';
                if (altKey) {
                    modifier = 'alt';
                }
                else if (ctrlKey) {
                    modifier = 'ctrl';
                }
                else if (metaKey) {
                    modifier = 'meta';
                }
                else if (shiftKey) {
                    modifier = 'shift';
                }
                // const modifiers = getModifiersFromMouseEvt(evt)
                const url = el.getAttr('href');
                const matchedMB = this.settings.modifierBindings.find((mb) => {
                    if (mb.auxClickOnly && button != MouseButton.Auxiliary) {
                        return false;
                    }
                    else {
                        return mb.modifier === modifier;
                    }
                });
                const profileName = (_a = matchedMB === null || matchedMB === void 0 ? void 0 : matchedMB.browser) !== null && _a !== void 0 ? _a : this.settings.selected;
                const paneType = el.getAttr('target') === '_blank'
                    ? 'window' // higher priority
                    : el.getAttr('oolw-pane-type') || undefined;
                const cmd = this._getOpenCMD(profileName);
                if (this.settings.enableLog) {
                    log('info', 'click event (extLinkClick)', {
                        click: {
                            button,
                            altKey,
                            ctrlKey,
                            metaKey,
                            shiftKey,
                        },
                        el,
                        modifier,
                        mouseEvent: evt,
                        win: evt.doc.win,
                        mid: evt.doc.win.mid,
                        url,
                        profileName,
                        paneType,
                        cmd,
                        matchedBinding: matchedMB,
                    });
                }
                // right click trigger (windows only)
                if (typeof options.allowedButton != 'undefined' &&
                    button != options.allowedButton) {
                    return;
                }
                // in-app view
                if (profileName === BROWSER_IN_APP.val) {
                    evt.preventDefault();
                    this._viewmgr.createView(url, ViewMode.NEW, {
                        focus: matchedMB === null || matchedMB === void 0 ? void 0 : matchedMB.focusOnView,
                        paneType,
                    });
                    return;
                }
                if (profileName === BROWSER_IN_APP_LAST.val) {
                    evt.preventDefault();
                    this._viewmgr.createView(url, ViewMode.LAST, {
                        focus: matchedMB === null || matchedMB === void 0 ? void 0 : matchedMB.focusOnView,
                        paneType,
                    });
                    return;
                }
                // web viewer (Obsidian 1.9+)
                if (profileName === BROWSER_WEB_VIEWER.val) {
                    evt.preventDefault();
                    this._viewmgr.createWebViewerView(url, ViewMode.NEW, {
                        focus: matchedMB === null || matchedMB === void 0 ? void 0 : matchedMB.focusOnView,
                        paneType,
                    });
                    return;
                }
                if (typeof cmd !== 'undefined') {
                    evt.preventDefault();
                    const code = yield openWith(url, cmd, {
                        enableLog: this.settings.enableLog,
                        timeout: this.settings.timeout,
                    });
                    if (code !== 0) {
                        if (this.settings.enableLog) {
                            log('error', 'failed to open', `'spawn' exited with code ${code} when ` +
                                `trying to open an external link with ${profileName}.`);
                        }
                        win._builtInOpen(url);
                    }
                }
                else {
                    win._builtInOpen(url);
                }
            });
            //
            this.addSettingTab(new SettingTab(this.app, this));
            //
            this._windowUtils = new WindowUtils(this);
            this._clickUtils = new ClickUtils(this, this._windowUtils);
            const initWindow = (win) => {
                this._windowUtils.registerWindow(win);
                this._clickUtils.overrideDefaultWindowOpen(win, true);
                this._clickUtils.initDocClickHandler(win);
                this.registerDomEvent(win, 'click', (evt) => {
                    return extLinkClick(evt, 'oolw-external-link-dummy', {
                        allowedButton: MouseButton.Main,
                    });
                });
                this.registerDomEvent(win, 'auxclick', (evt) => {
                    return extLinkClick(evt, 'oolw-external-link-dummy', {
                        allowedButton: MouseButton.Auxiliary,
                    });
                });
            };
            initWindow(activeWindow);
            this.app.workspace.on('window-open', (ww, win) => {
                initWindow(win);
            });
            this.app.workspace.on('window-close', (ww, win) => {
                this._oolwUnloadWindow(win);
            });
            //
            this.app.workspace.onLayoutReady(() => __awaiter(this, void 0, void 0, function* () {
                yield this._viewmgr.restoreView();
                if (this.settings.enableLog) {
                    log('info', 'restored views', this.settings.inAppViewRec);
                }
            }));
        });
    }
    onunload() {
        return __awaiter(this, void 0, void 0, function* () {
            if (typeof this._windowUtils !== 'undefined') {
                Object.keys(this._windowUtils.getRecords()).forEach((mid) => {
                    this._oolwUnloadWindowByMID(mid);
                });
                delete this._clickUtils;
                delete this._windowUtils;
            }
        });
    }
    loadSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            this.settings = Object.assign({}, DEFAULT_SETTINGS, yield this.loadData());
        });
    }
    saveSettings() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.settings.enableLog) {
                log('info', 'saving settings', this.settings);
            }
            yield this.saveData(this.settings);
        });
    }
    _getOpenCMD(val) {
        if (val === BROWSER_SYSTEM.val) {
            return undefined;
        }
        if (val === BROWSER_GLOBAL.val) {
            val = this.settings.selected;
        }
        return this.profiles.getBrowsersCMD(this.settings.custom)[val];
    }
    _oolwUnloadWindow(win) {
        if (typeof this._clickUtils !== 'undefined') {
            this._clickUtils.removeDocClickHandler(win);
            this._clickUtils.overrideDefaultWindowOpen(win, false);
        }
        if (typeof this._windowUtils !== 'undefined') {
            this._windowUtils.unregisterWindow(win);
        }
    }
    _oolwUnloadWindowByMID(mid) {
        if (typeof this._windowUtils !== 'undefined') {
            const win = this._windowUtils.getWindow(mid);
            if (typeof win !== 'undefined') {
                this._oolwUnloadWindow(win);
            }
        }
    }
}
class PanicModal extends obsidian.Modal {
    constructor(app, message) {
        super(app);
        this.message = message;
        this.message = message;
    }
    onOpen() {
        let { contentEl } = this;
        contentEl.setText(this.message);
    }
    onClose() {
        let { contentEl } = this;
        contentEl.empty();
    }
}
class SettingTab extends obsidian.PluginSettingTab {
    constructor(app, plugin) {
        super(app, plugin);
        this.plugin = plugin;
        this.plugin = plugin;
        this._profileChangeHandler = obsidian.debounce((val) => __awaiter(this, void 0, void 0, function* () {
            var _a, _b;
            try {
                const profiles = JSON.parse(val);
                this.plugin.settings.custom = profiles;
                yield this.plugin.saveSettings();
                this._render();
            }
            catch (e) {
                this.panic((_b = (_a = e.message) !== null && _a !== void 0 ? _a : e.toString()) !== null && _b !== void 0 ? _b : 'some error occurred in open-link-with');
            }
        }), 1500, true);
        this._timeoutChangeHandler = obsidian.debounce((val) => __awaiter(this, void 0, void 0, function* () {
            const timeout = parseInt(val);
            if (Number.isNaN(timeout)) {
                this.panic('Value of timeout should be interger.');
            }
            else {
                this.plugin.settings.timeout = timeout;
                yield this.plugin.saveSettings();
                this._render();
            }
        }), 1500, true);
    }
    panic(msg) {
        new PanicModal(this.app, msg).open();
    }
    _render() {
        let { containerEl } = this;
        containerEl.empty();
        new obsidian.Setting(containerEl)
            .setName('Browser')
            .setDesc('Open external link with selected browser.')
            .addDropdown((dd) => {
            const browsers = [
                BROWSER_SYSTEM,
                BROWSER_IN_APP_LAST,
                BROWSER_IN_APP,
                BROWSER_WEB_VIEWER,
                ...Object.keys(this.plugin.profiles.getBrowsersCMD(this.plugin.settings.custom)).map((b) => {
                    return { val: b };
                }),
            ];
            let current = browsers.findIndex(({ val }) => val === this.plugin.settings.selected);
            if (current !== -1) {
                browsers.unshift(browsers.splice(current, 1)[0]);
            }
            browsers.forEach((b) => { var _a; return dd.addOption(b.val, (_a = b.display) !== null && _a !== void 0 ? _a : b.val); });
            dd.onChange((p) => __awaiter(this, void 0, void 0, function* () {
                this.plugin.settings.selected = p;
                yield this.plugin.saveSettings();
            }));
        });
        new obsidian.Setting(containerEl)
            .setName('Customization')
            .setDesc('Customization profiles in JSON.')
            .addTextArea((text) => text
            .setPlaceholder('{}')
            .setValue(JSON.stringify(this.plugin.settings.custom, null, 4))
            .onChange(this._profileChangeHandler));
        const mbSetting = new obsidian.Setting(containerEl)
            .setName('Modifier Bindings')
            .setDesc('Matching from top to bottom')
            .addButton((btn) => {
            btn.setButtonText('New');
            btn.onClick((_) => __awaiter(this, void 0, void 0, function* () {
                this.plugin.settings.modifierBindings.unshift({
                    id: genRandomStr(6),
                    platform: Platform.Unknown,
                    modifier: 'none',
                    focusOnView: true,
                    auxClickOnly: false,
                });
                yield this.plugin.saveSettings();
                this._render();
            }));
        });
        const mbSettingEl = mbSetting.settingEl;
        mbSettingEl.setAttr('style', 'flex-wrap:wrap');
        const bindings = this.plugin.settings.modifierBindings;
        bindings.forEach((mb) => {
            const ctr = document.createElement('div');
            ctr.setAttr('style', 'flex-basis:100%;height:auto;margin-top:18px');
            const mini = document.createElement('div');
            const kb = new obsidian.Setting(mini);
            kb.addDropdown((dd) => {
                var _a;
                const browsers = [
                    BROWSER_GLOBAL,
                    BROWSER_IN_APP_LAST,
                    BROWSER_IN_APP,
                    BROWSER_WEB_VIEWER,
                    ...Object.keys(this.plugin.profiles.getBrowsersCMD(this.plugin.settings.custom)).map((b) => {
                        return { val: b };
                    }),
                    BROWSER_SYSTEM,
                ];
                browsers.forEach((b) => {
                    var _a;
                    dd.addOption(b.val, (_a = b.display) !== null && _a !== void 0 ? _a : b.val);
                });
                dd.setValue((_a = mb.browser) !== null && _a !== void 0 ? _a : BROWSER_GLOBAL.val);
                dd.onChange((browser) => __awaiter(this, void 0, void 0, function* () {
                    if (browser === BROWSER_GLOBAL.val) {
                        browser = undefined;
                    }
                    this.plugin.settings.modifierBindings.find((m) => m.id === mb.id).browser = browser;
                    yield this.plugin.saveSettings();
                    this._render();
                }));
            });
            kb.addToggle((toggle) => {
                toggle.toggleEl.setAttribute('id', 'oolw-aux-click-toggle');
                toggle.setValue(mb.auxClickOnly);
                toggle.setTooltip('Triggers on middle mouse button click only');
                toggle.onChange((val) => __awaiter(this, void 0, void 0, function* () {
                    this.plugin.settings.modifierBindings.find((m) => m.id === mb.id).auxClickOnly = val;
                    yield this.plugin.saveSettings();
                }));
            });
            kb.addToggle((toggle) => {
                toggle.toggleEl.setAttribute('id', 'oolw-view-focus-toggle');
                if (mb.browser === BROWSER_IN_APP.val ||
                    mb.browser === BROWSER_IN_APP_LAST.val ||
                    mb.browser === BROWSER_WEB_VIEWER.val) {
                    toggle.setDisabled(false);
                    toggle.setValue(mb.focusOnView);
                }
                else {
                    toggle.toggleEl.setAttribute('style', 'opacity:0.2');
                    toggle.setDisabled(true);
                    toggle.setValue(false);
                }
                toggle.setTooltip('Focus on view after opening/updating (in-app browser and web viewer only)');
                toggle.onChange((val) => __awaiter(this, void 0, void 0, function* () {
                    this.plugin.settings.modifierBindings.find((m) => m.id === mb.id).focusOnView = val;
                    yield this.plugin.saveSettings();
                }));
            });
            kb.addDropdown((dd) => {
                const platform = getPlatform();
                getValidModifiers(platform).forEach((m) => {
                    dd.addOption(m, Object.assign(Object.assign({}, MODIFIER_TEXT_FALLBACK), MODIFIER_TEXT[platform])[m]);
                });
                dd.setValue(mb.modifier);
                dd.onChange((modifier) => __awaiter(this, void 0, void 0, function* () {
                    this.plugin.settings.modifierBindings.find((m) => m.id === mb.id).modifier = modifier;
                    yield this.plugin.saveSettings();
                }));
            });
            kb.addButton((btn) => {
                btn.setButtonText('Remove');
                btn.setClass('mod-warning');
                btn.onClick((_) => __awaiter(this, void 0, void 0, function* () {
                    const idx = this.plugin.settings.modifierBindings.findIndex((m) => m.id === mb.id);
                    this.plugin.settings.modifierBindings.splice(idx, 1);
                    yield this.plugin.saveSettings();
                    this._render();
                }));
            });
            kb.controlEl.setAttr('style', 'justify-content: space-between !important;');
            mbSettingEl.appendChild(ctr);
            ctr.appendChild(kb.controlEl);
        });
        new obsidian.Setting(containerEl)
            .setName('Logs')
            .setDesc('Display logs in console (open developer tools to view).')
            .addToggle((toggle) => {
            toggle.setValue(this.plugin.settings.enableLog);
            toggle.onChange((val) => __awaiter(this, void 0, void 0, function* () {
                this.plugin.settings.enableLog = val;
                yield this.plugin.saveSettings();
                this._render();
            }));
        });
        new obsidian.Setting(containerEl)
            .setName('Timeout')
            .addText((text) => text
            .setPlaceholder('500')
            .setValue(this.plugin.settings.timeout.toString())
            .onChange(this._timeoutChangeHandler));
    }
    display() {
        this._render();
    }
}

module.exports = OpenLinkPlugin;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZXMiOlsiLi4vbm9kZV9tb2R1bGVzL3RzbGliL3RzbGliLmVzNi5qcyIsIi4uL3NyYy90eXBlcy50cyIsIi4uL3NyYy91dGlscy50cyIsIi4uL3NyYy9jbGljay50cyIsIi4uL3NyYy9jb25zdGFudC50cyIsIi4uL3NyYy9vcGVuLnRzIiwiLi4vc3JjL3Byb2ZpbGUudHMiLCIuLi9zcmMvdmlldy50cyIsIi4uL3NyYy9tYWluLnRzIl0sInNvdXJjZXNDb250ZW50IjpudWxsLCJuYW1lcyI6WyJNUiIsIlBsYXRmb3JtIiwiZXhpc3RzU3luYyIsInNwYXduU3luYyIsInBhdGgiLCJzcGF3biIsIm9zIiwicGxhdGZvcm0iLCJJdGVtVmlldyIsIlBsdWdpbiIsIk1vZGFsIiwiUGx1Z2luU2V0dGluZ1RhYiIsImRlYm91bmNlIiwiU2V0dGluZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFvR0E7QUFDTyxTQUFTLFNBQVMsQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLENBQUMsRUFBRSxTQUFTLEVBQUU7QUFDN0QsSUFBSSxTQUFTLEtBQUssQ0FBQyxLQUFLLEVBQUUsRUFBRSxPQUFPLEtBQUssWUFBWSxDQUFDLEdBQUcsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLFVBQVUsT0FBTyxFQUFFLEVBQUUsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUU7QUFDaEgsSUFBSSxPQUFPLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPLENBQUMsRUFBRSxVQUFVLE9BQU8sRUFBRSxNQUFNLEVBQUU7QUFDL0QsUUFBUSxTQUFTLFNBQVMsQ0FBQyxLQUFLLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO0FBQ25HLFFBQVEsU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO0FBQ3RHLFFBQVEsU0FBUyxJQUFJLENBQUMsTUFBTSxFQUFFLEVBQUUsTUFBTSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFO0FBQ3RILFFBQVEsSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLFVBQVUsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO0FBQzlFLEtBQUssQ0FBQyxDQUFDO0FBQ1AsQ0FBQztBQTZNRDtBQUN1QixPQUFPLGVBQWUsS0FBSyxVQUFVLEdBQUcsZUFBZSxHQUFHLFVBQVUsS0FBSyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUU7QUFDdkgsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQixJQUFJLE9BQU8sQ0FBQyxDQUFDLElBQUksR0FBRyxpQkFBaUIsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUMsVUFBVSxHQUFHLFVBQVUsRUFBRSxDQUFDLENBQUM7QUFDckY7O0FDdlVBLElBQVUsSUFBSSxDQWtCYjtBQWxCRCxDQUFBLFVBQVUsSUFBSSxFQUFBO0FBQ1YsSUFBQSxNQUFhLEtBQUssQ0FBQTtRQUNkLFdBQW1CLENBQUEsS0FBVSxFQUFTLEtBQVEsRUFBQTtZQUEzQixJQUFLLENBQUEsS0FBQSxHQUFMLEtBQUssQ0FBSztZQUFTLElBQUssQ0FBQSxLQUFBLEdBQUwsS0FBSyxDQUFHO1NBQUk7QUFDckQsS0FBQTtBQUZZLElBQUEsSUFBQSxDQUFBLEtBQUssUUFFakIsQ0FBQTtJQUVELE1BQWEsS0FBWSxTQUFRLEtBQVcsQ0FBQTtBQUN4QyxRQUFBLFdBQUEsQ0FBWSxLQUFRLEVBQUE7QUFDaEIsWUFBQSxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFBO1NBQ25CO0FBQ0osS0FBQTtBQUpZLElBQUEsSUFBQSxDQUFBLEtBQUssUUFJakIsQ0FBQTtJQUVELE1BQWEsS0FBWSxTQUFRLEtBQVcsQ0FBQTtBQUFHLEtBQUE7QUFBbEMsSUFBQSxJQUFBLENBQUEsS0FBSyxRQUE2QixDQUFBO0lBRS9DLE1BQWEsUUFBZSxTQUFRLEtBQVcsQ0FBQTtBQUFHLEtBQUE7QUFBckMsSUFBQSxJQUFBLENBQUEsUUFBUSxXQUE2QixDQUFBO0lBRWxELE1BQWEsUUFBZSxTQUFRLEtBQVcsQ0FBQTtBQUFHLEtBQUE7QUFBckMsSUFBQSxJQUFBLENBQUEsUUFBUSxXQUE2QixDQUFBO0lBRWxELE1BQWEsV0FBa0IsU0FBUSxLQUFXLENBQUE7QUFBRyxLQUFBO0FBQXhDLElBQUEsSUFBQSxDQUFBLFdBQVcsY0FBNkIsQ0FBQTtBQUN6RCxDQUFDLEVBbEJTLElBQUksS0FBSixJQUFJLEdBa0JiLEVBQUEsQ0FBQSxDQUFBLENBQUE7QUFFRCxJQUFLLFFBS0osQ0FBQTtBQUxELENBQUEsVUFBSyxRQUFRLEVBQUE7QUFDVCxJQUFBLFFBQUEsQ0FBQSxTQUFBLENBQUEsR0FBQSxTQUFtQixDQUFBO0FBQ25CLElBQUEsUUFBQSxDQUFBLE9BQUEsQ0FBQSxHQUFBLE9BQWUsQ0FBQTtBQUNmLElBQUEsUUFBQSxDQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQVcsQ0FBQTtBQUNYLElBQUEsUUFBQSxDQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQVcsQ0FBQTtBQUNmLENBQUMsRUFMSSxRQUFRLEtBQVIsUUFBUSxHQUtaLEVBQUEsQ0FBQSxDQUFBLENBQUE7QUFFRCxJQUFLLFFBS0osQ0FBQTtBQUxELENBQUEsVUFBSyxRQUFRLEVBQUE7QUFDVCxJQUFBLFFBQUEsQ0FBQSxLQUFBLENBQUEsR0FBQSxLQUFXLENBQUE7QUFDWCxJQUFBLFFBQUEsQ0FBQSxNQUFBLENBQUEsR0FBQSxNQUFhLENBQUE7QUFDYixJQUFBLFFBQUEsQ0FBQSxNQUFBLENBQUEsR0FBQSxNQUFhLENBQUE7QUFDYixJQUFBLFFBQUEsQ0FBQSxPQUFBLENBQUEsR0FBQSxPQUFlLENBQUE7QUFDbkIsQ0FBQyxFQUxJLFFBQVEsS0FBUixRQUFRLEdBS1osRUFBQSxDQUFBLENBQUEsQ0FBQTtBQUVELElBQUssV0FNSixDQUFBO0FBTkQsQ0FBQSxVQUFLLFdBQVcsRUFBQTtBQUNaLElBQUEsV0FBQSxDQUFBLFdBQUEsQ0FBQSxNQUFBLENBQUEsR0FBQSxDQUFBLENBQUEsR0FBQSxNQUFJLENBQUE7QUFDSixJQUFBLFdBQUEsQ0FBQSxXQUFBLENBQUEsV0FBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLEdBQUEsV0FBUyxDQUFBO0FBQ1QsSUFBQSxXQUFBLENBQUEsV0FBQSxDQUFBLFdBQUEsQ0FBQSxHQUFBLENBQUEsQ0FBQSxHQUFBLFdBQVMsQ0FBQTtBQUNULElBQUEsV0FBQSxDQUFBLFdBQUEsQ0FBQSxRQUFBLENBQUEsR0FBQSxDQUFBLENBQUEsR0FBQSxRQUFNLENBQUE7QUFDTixJQUFBLFdBQUEsQ0FBQSxXQUFBLENBQUEsT0FBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLEdBQUEsT0FBSyxDQUFBO0FBQ1QsQ0FBQyxFQU5JLFdBQVcsS0FBWCxXQUFXLEdBTWYsRUFBQSxDQUFBLENBQUEsQ0FBQTtBQUVELElBQUssUUFHSixDQUFBO0FBSEQsQ0FBQSxVQUFLLFFBQVEsRUFBQTtBQUNULElBQUEsUUFBQSxDQUFBLFFBQUEsQ0FBQSxNQUFBLENBQUEsR0FBQSxDQUFBLENBQUEsR0FBQSxNQUFJLENBQUE7QUFDSixJQUFBLFFBQUEsQ0FBQSxRQUFBLENBQUEsS0FBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLEdBQUEsS0FBRyxDQUFBO0FBQ1AsQ0FBQyxFQUhJLFFBQVEsS0FBUixRQUFRLEdBR1osRUFBQSxDQUFBLENBQUE7O0FDdkNELE1BQU0sWUFBWSxDQUFBO0FBQ2QsSUFBQSxXQUFBLENBQW9CLFNBQTJCLEVBQUUsRUFBQTtRQUE3QixJQUFNLENBQUEsTUFBQSxHQUFOLE1BQU0sQ0FBdUI7S0FBSTtBQUNyRCxJQUFBLE9BQU8sQ0FBQyxJQUFvQixFQUFBO0FBQ3hCLFFBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7S0FDekI7QUFDRCxJQUFBLEtBQUssQ0FBQyxLQUFVLEVBQUUsT0FBQSxHQUE2QyxFQUFFLEVBQUE7O1FBQzdELE1BQU0sT0FBTyxHQUFRLEVBQUUsQ0FBQTtBQUN2QixRQUFBLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUM1QixJQUNJLENBQUMsQ0FBQSxFQUFBLEdBQUEsT0FBTyxLQUFQLElBQUEsSUFBQSxPQUFPLEtBQVAsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsT0FBTyxDQUFFLG1CQUFtQixNQUFJLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxHQUFBLEtBQUs7QUFDdEMsZ0JBQUEsT0FBTyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQ3BCO2dCQUNFLE1BQUs7QUFDUixhQUFBO0FBQ0QsWUFBQSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFBO1lBQ3RCLElBQUksSUFBSSxZQUFZQSxJQUFFLENBQUMsS0FBSyxJQUFJLElBQUksWUFBWUEsSUFBRSxDQUFDLFFBQVEsRUFBRTtnQkFDekQsSUFBSSxFQUFFLEdBQUcsS0FBSyxDQUFBO0FBQ2QsZ0JBQUEsSUFBSSxLQUFLLENBQUMsTUFBTSxLQUFLLEtBQUssQ0FBQyxNQUFNLEVBQUU7QUFDL0Isb0JBQUEsRUFBRSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEtBQUssS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO0FBQ25ELGlCQUFBO0FBQ0QsZ0JBQUEsSUFBSSxJQUFJLFlBQVlBLElBQUUsQ0FBQyxLQUFLLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxFQUFFO0FBQ3JDLG9CQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzNCLGlCQUFBO0FBQ0osYUFBQTtBQUFNLGlCQUFBLElBQ0gsSUFBSSxZQUFZQSxJQUFFLENBQUMsUUFBUTtBQUMzQixnQkFBQSxJQUFJLFlBQVlBLElBQUUsQ0FBQyxXQUFXLEVBQ2hDO2dCQUNFLElBQUksRUFBRSxHQUFHLEtBQUssQ0FBQTtBQUNkLGdCQUFBLElBQUksS0FBSyxDQUFDLE1BQU0sSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFO0FBQzlCLG9CQUFBLEVBQUUsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxLQUFLLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtBQUNuRCxpQkFBQTtBQUNELGdCQUFBLElBQUksSUFBSSxZQUFZQSxJQUFFLENBQUMsUUFBUSxHQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUUsRUFBRTtBQUN4QyxvQkFBQSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUMzQixpQkFBQTtBQUNKLGFBQUE7QUFBTSxpQkFBQSxJQUFJLElBQUksWUFBWUEsSUFBRSxDQUFDLEtBQUssRUFBRTtBQUNqQyxnQkFBQSxJQUFJLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO0FBQ3BCLG9CQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzNCLGlCQUFBO0FBQ0osYUFBQTtBQUFNLGlCQUFBO2dCQUNILE1BQU0sSUFBSSxTQUFTLENBQ2YsQ0FBc0IsbUJBQUEsRUFBQSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBRSxDQUFBLENBQ2hELENBQUE7QUFDSixhQUFBO0FBQ0osU0FBQTtBQUNELFFBQUEsT0FBTyxPQUFPLENBQUE7S0FDakI7QUFDSixDQUFBO0FBRUQsTUFBTSxXQUFXLENBQUE7QUFFYixJQUFBLFdBQUEsQ0FBb0IsT0FBMEIsRUFBQTtRQUExQixJQUFPLENBQUEsT0FBQSxHQUFQLE9BQU8sQ0FBbUI7QUFDMUMsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQTtLQUNyQjtBQUNELElBQUEsVUFBVSxDQUFDLEdBQVksRUFBQTtBQUNuQixRQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3pCLFFBQUEsT0FBTyxHQUFHLENBQUE7S0FDYjtBQUNELElBQUEsY0FBYyxDQUFDLEdBQVksRUFBQTtBQUN2QixRQUFBLElBQUksT0FBTyxHQUFHLENBQUMsR0FBRyxLQUFLLFdBQVcsRUFBRTtBQUNoQyxZQUFBLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQzFCLFlBQUEsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7QUFDakMsZ0JBQUEsR0FBRyxDQUFDLE1BQU0sRUFBRSxtQkFBbUIsRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFBO0FBQ2xFLGFBQUE7WUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUE7QUFDL0IsU0FRQTtLQUNKO0FBQ0QsSUFBQSxnQkFBZ0IsQ0FBQyxHQUFZLEVBQUE7QUFDekIsUUFBQSxJQUFJLE9BQU8sR0FBRyxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUU7WUFDaEMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUM3QixZQUFBLEdBQUcsQ0FBQyxNQUFNLEVBQUUscUJBQXFCLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQTtBQUNqRSxZQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsU0FBUyxDQUFBO0FBQ3RCLFNBQUE7S0FDSjtJQUNELFVBQVUsR0FBQTtRQUNOLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQTtLQUN2QjtBQUNELElBQUEsU0FBUyxDQUFDLEdBQVcsRUFBQTtBQUNqQixRQUFBLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtLQUM1QjtBQUNKLENBQUE7QUFFRCxNQUFNLFdBQVcsR0FBRyxNQUFlO0FBQy9CLElBQUEsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUE7SUFDMUMsUUFBUSxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDeEIsUUFBQSxLQUFLLEtBQUs7WUFDTixPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUE7QUFDdkIsUUFBQSxLQUFLLEtBQUs7WUFDTixPQUFPLFFBQVEsQ0FBQyxHQUFHLENBQUE7QUFDdkIsUUFBQTtZQUNJLE9BQU8sUUFBUSxDQUFDLEtBQUssQ0FBQTtBQUM1QixLQUFBO0FBQ0wsQ0FBQyxDQUFBO0FBRUQsTUFBTSx3QkFBd0IsR0FBRyxDQUFDLEdBQWUsS0FBZ0I7SUFDN0QsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxHQUFHLEdBQUcsQ0FBQTtJQUNsRCxNQUFNLElBQUksR0FBZSxFQUFFLENBQUE7QUFDM0IsSUFBQSxJQUFJLE1BQU0sRUFBRTtBQUNSLFFBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDMUIsS0FBQTtBQUNELElBQUEsSUFBSSxPQUFPLEVBQUU7QUFDVCxRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQzNCLEtBQUE7QUFDRCxJQUFBLElBQUksT0FBTyxFQUFFO0FBQ1QsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUMzQixLQUFBO0FBQ0QsSUFBQSxJQUFJLFFBQVEsRUFBRTtBQUNWLFFBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDNUIsS0FBQTtBQUNELElBQUEsT0FBTyxJQUFJLENBQUE7QUFDZixDQUFDLENBQUE7QUFFRCxNQUFNLGFBQWEsR0FBRyxDQUFDLEtBQWEsS0FBWTtJQUM1QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEtBQUssQ0FBQztTQUNuQyxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQ2YsU0FBQSxpQkFBaUIsRUFBRSxDQUFBO0FBQzVCLENBQUMsQ0FBQTtBQUVELE1BQU0sWUFBWSxHQUFHLENBQUMsR0FBVyxLQUFZO0lBQ3pDLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQTtJQUNiLEtBQUssTUFBTSxDQUFDLElBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUM3QixFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO0FBQzdCLEtBQUE7QUFDRCxJQUFBLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUN0QixDQUFDLENBQUE7QUFFRCxNQUFNLGVBQWUsR0FBRyxDQUFDLEdBQWtCLEtBQW1CO0FBQzFELElBQUEsSUFBSSxPQUFPLEdBQUcsS0FBSyxXQUFXLEVBQUU7QUFDNUIsUUFBQSxPQUFPLElBQUksQ0FBQTtBQUNkLEtBQUE7U0FBTSxJQUFJLEdBQUcsWUFBWSxHQUFHLEVBQUU7QUFDM0IsUUFBQSxPQUFPLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xELGNBQUUsR0FBRyxDQUFDLFFBQVEsRUFBRTtjQUNkLElBQUksQ0FBQTtBQUNiLEtBQUE7QUFBTSxTQUFBO1FBQ0gsSUFBSTtZQUNBLE9BQU8sZUFBZSxDQUFDLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7QUFDdkMsU0FBQTtBQUFDLFFBQUEsT0FBTyxTQUFTLEVBQUU7QUFDaEIsWUFBQSxPQUFPLElBQUksQ0FBQTtBQUNkLFNBQUE7QUFDSixLQUFBO0FBQ0wsQ0FBQyxDQUFBO0FBRUQsTUFBTSxpQkFBaUIsR0FBRyxDQUFDLFFBQWtCLEtBQXFCO0FBQzlELElBQUEsSUFBSSxRQUFRLEtBQUssUUFBUSxDQUFDLE9BQU8sRUFBRTtRQUMvQixPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDbEIsS0FBQTtBQUFNLFNBQUE7UUFDSCxPQUFPLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBQ2xELEtBQUE7QUFDTCxDQUFDLENBQUE7QUFXRCxNQUFNLEdBQUcsR0FBRyxDQUFDLEtBQWdCLEVBQUUsS0FBYSxFQUFFLE9BQVksS0FBSTtBQUMxRCxJQUFBLElBQUksTUFBK0IsQ0FBQTtJQUNuQyxJQUFJLEtBQUssS0FBSyxNQUFNLEVBQUU7QUFDbEIsUUFBQSxNQUFNLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQTtBQUN4QixLQUFBO1NBQU0sSUFBSSxLQUFLLEtBQUssT0FBTyxFQUFFO0FBQzFCLFFBQUEsTUFBTSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUE7QUFDekIsS0FBQTtBQUFNLFNBQUE7QUFDSCxRQUFBLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFBO0FBQ3hCLEtBQUE7QUFDRCxJQUFBLE1BQU0sQ0FBQyxDQUFvQixpQkFBQSxFQUFBLEtBQUssRUFBRSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBQ2hELENBQUM7O0FDeEtELE1BQU0sY0FBYyxHQUFHLENBQUMsRUFBVyxLQUFlO0FBQzlDLElBQUEsTUFBTSxHQUFHLEdBQUc7QUFDUixRQUFBLFlBQVksRUFBRSxLQUFLO0FBQ25CLFFBQUEsR0FBRyxFQUFFLElBQUk7QUFDVCxRQUFBLFFBQVEsRUFBRSxTQUFTO0FBQ25CLFFBQUEsY0FBYyxFQUFFLEVBQUU7S0FDUixDQUFBO0FBQ2QsSUFBQSxNQUFNLElBQUksR0FBR0MsaUJBQVEsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFBO0FBQzdELElBQUEsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQTtBQUN4QixJQUFBLE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUE7O0lBRTVCLElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7QUFDeEMsUUFBQSxHQUFHLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQTtRQUN2QixHQUFHLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUE7UUFDakMsR0FBRyxDQUFDLGNBQWMsR0FBRztZQUNqQixJQUFJRCxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsS0FBSyxDQUFDO1lBQzNCLElBQUlBLElBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLEVBQUUsT0FBTyxDQUFDO1lBQ2xDLElBQUlBLElBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDO0FBQ2xDLFlBQUEsSUFBSUEsSUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLEVBQUUsUUFBUSxDQUFDO1lBQzFDLElBQUlBLElBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLFNBQVMsQ0FBQztTQUNqQyxDQUFBO0FBQ0osS0FBQTs7SUFFRCxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FHNUM7O0lBRUQsSUFBSSxFQUFFLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRTtBQUN2QyxRQUFBLEdBQUcsQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFBOztRQUV2QixHQUFHLENBQUMsY0FBYyxHQUFHO0FBQ2pCLFlBQUEsSUFBSUEsSUFBRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7WUFDdkIsSUFBSUEsSUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQztZQUMzQixJQUFJQSxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQztZQUNsQyxJQUFJQSxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQztBQUNsQyxZQUFBLElBQUlBLElBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFFLFFBQVEsQ0FBQztTQUM3QyxDQUFBO0FBQ0osS0FBQTs7SUFFRCxJQUFJLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ2pDLFFBQUEsR0FBRyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUE7O1FBRXZCLEdBQUcsQ0FBQyxjQUFjLEdBQUc7WUFDakIsSUFBSUEsSUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsQ0FBQztZQUMvQixJQUFJQSxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxFQUFFLE9BQU8sQ0FBQztZQUNsQyxJQUFJQSxJQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFFLEtBQUssQ0FBQztBQUNsQyxZQUFBLElBQUlBLElBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxFQUFFLFFBQVEsQ0FBQztTQUM3QyxDQUFBO0FBQ0osS0FBQTs7SUFFRCxJQUFJLEdBQUcsQ0FBQyxZQUFZLEtBQUssS0FBSyxJQUFJLEVBQUUsQ0FBQyxPQUFPLEtBQUssR0FBRyxFQUFFO1FBQ2xELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQTtBQUNWLFFBQUEsT0FBTyxDQUFDLENBQUMsT0FBTyxLQUFLLE1BQU0sRUFBRTtZQUN6QixJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO2dCQUN2QyxNQUFLO0FBQ1IsYUFBQTtpQkFBTSxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEVBQUU7QUFDckQsZ0JBQUEsR0FBRyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUE7Z0JBQ3ZCLEdBQUcsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNqQyxnQkFBQSxHQUFHLENBQUMsUUFBUTtBQUNSLG9CQUFBLEVBQUUsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUTtBQUNsQywwQkFBRSxRQUFRO0FBQ1YsMEJBQUUsR0FBRyxDQUFDLFFBQVEsQ0FBQTtnQkFDdEIsTUFBSztBQUNSLGFBQUE7QUFDRCxZQUFBLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFBO0FBQ3RCLFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxPQUFPLEdBQUcsQ0FBQTtBQUNkLENBQUMsQ0FBQTtBQUVELE1BQU0sb0JBQW9CLENBQUE7QUFHdEIsSUFBQSxXQUFBLENBQW1CLFVBQXNCLEVBQUE7UUFBdEIsSUFBVSxDQUFBLFVBQUEsR0FBVixVQUFVLENBQVk7QUFDckMsUUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQTtBQUNyQixRQUFBLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFBO0tBQy9CO0FBQ0QsSUFBQSxJQUFJLE9BQU8sR0FBQTtRQUNQLE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQTtLQUN2QjtJQUNELElBQUksT0FBTyxDQUFDLEdBQVksRUFBQTtBQUNwQixRQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFBO0tBQ3RCO0FBQ0QsSUFBQSxJQUFJLGNBQWMsR0FBQTtRQUNkLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQTtLQUM5QjtJQUNELElBQUksY0FBYyxDQUFDLEdBQVksRUFBQTtBQUMzQixRQUFBLElBQUksQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFBO0tBQzdCO0FBQ0QsSUFBQSxJQUFJLENBQUMsR0FBZSxFQUFBO0FBQ2hCLFFBQUEsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFjLENBQUE7UUFDbEMsSUFBSSxPQUFPLEdBQUcsQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDakQsWUFBQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3JCLFNBSUE7S0FDSjtBQUNTLElBQUEsUUFBUSxDQUFDLEdBQWUsRUFBQTtBQUM5QixRQUFBLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFpQixDQUFBO0FBQ2hDLFFBQUEsTUFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFjLENBQUE7QUFDbEMsUUFBQSxNQUFNLFNBQVMsR0FBRyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUMvQyxRQUFBLE1BQU0sU0FBUyxHQUFHLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNwQyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUE7QUFDZixRQUFBLElBQUksR0FBRyxHQUFXLFNBQVMsQ0FBQyxHQUFHLENBQUE7QUFDL0IsUUFBQSxJQUFJLEdBQUcsQ0FBQyxlQUFlLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7QUFFaEMsWUFBQSxHQUFHLEdBQUcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtBQUNsQyxTQUFBO0FBQU0sYUFBQTs7WUFFSCxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ3ZDLElBQUksR0FBRyxLQUFLLENBQUE7QUFDWixnQkFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3hCLGFBQUE7QUFDSixTQUFBO1FBQ0QsSUFBSSxTQUFTLENBQUMsWUFBWSxLQUFLLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxFQUFFO0FBQ2xELFlBQUEsT0FBTyxLQUFLLENBQUE7QUFDZixTQUFBO0FBQ0QsUUFBQSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsU0FBUyxDQUFBO1FBQzVCLElBQUksR0FBRyxLQUFLLElBQUksRUFBRTtZQUNkLElBQUksR0FBRyxLQUFLLENBQUE7QUFDZixTQUFBO0FBQ0QsUUFBQSxJQUFJLFNBQVMsQ0FBQyxjQUFjLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtZQUNyQyxNQUFNLE9BQU8sR0FBRyxJQUFJLFlBQVksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUE7QUFDMUQsWUFBQSxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRTtBQUNyQyxnQkFBQSxtQkFBbUIsRUFBRSxJQUFJO0FBQzVCLGFBQUEsQ0FBQyxDQUFBO0FBQ0YsWUFBQSxJQUFJLE9BQU8sQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO2dCQUNyQixJQUFJLFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FFM0I7QUFBTSxxQkFBQTtvQkFDSCxJQUFJLEdBQUcsS0FBSyxDQUFBO0FBQ2YsaUJBQUE7QUFDSixhQUFBO0FBQU0saUJBQUEsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO2dCQUM3QixJQUFJLEdBQUcsS0FBSyxDQUFBO0FBQ2YsYUFBQTtBQUFNLGlCQUFBLElBQUksT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxFQUFFO2dCQUMxQyxRQUFRLEdBQUcsU0FBUyxDQUFBO0FBQ3ZCLGFBQUE7QUFBTSxpQkFBQTtBQUNILGdCQUFBLFFBQVEsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDeEIsYUFBQTtBQUNKLFNBQUE7O1FBRUQsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1lBQ3pDLElBQUksR0FBRyxLQUFLLENBQUE7QUFDZixTQUFBO1FBQ0QsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFBO1FBQ3BCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtBQUM1QyxZQUFBLEdBQUcsQ0FBQyxNQUFNLEVBQUUsb0NBQW9DLEVBQUU7Z0JBQzlDLE1BQU0sRUFBRSxJQUFJLENBQUMsY0FBYztnQkFDM0IsU0FBUztnQkFDVCxHQUFHO2dCQUNILFNBQVM7Z0JBQ1QsR0FBRyxFQUFFLEdBQUcsQ0FBQyxNQUFNO0FBQ2xCLGFBQUEsQ0FBQyxDQUFBO0FBQ0wsU0FBQTtRQUNELElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDUCxZQUFBLE9BQU8sS0FBSyxDQUFBO0FBQ2YsU0FBQTtRQUNELE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3hDLFFBQUEsTUFBTSxHQUFHLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQzNCLFFBQUEsS0FBSyxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUE7UUFDL0IsS0FBSyxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLElBQUksRUFBRSxDQUFDLENBQUE7QUFDcEQsUUFBQSxLQUFLLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQTtBQUNuQyxRQUFBLEtBQUssQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsQ0FBQTtRQUMxQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUE7O1FBRS9CLE1BQU0sSUFBSSxHQUFHLElBQUksVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUE7QUFDMUMsUUFBQSxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ3pCLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQTtLQUNqQjtBQUNKLENBQUE7QUFFRCxNQUFNLFVBQVUsQ0FBQTtJQVFaLFdBQ1csQ0FBQSxPQUEwQixFQUN6QixZQUF5QixFQUFBO1FBRDFCLElBQU8sQ0FBQSxPQUFBLEdBQVAsT0FBTyxDQUFtQjtRQUN6QixJQUFZLENBQUEsWUFBQSxHQUFaLFlBQVksQ0FBYTtBQUVqQyxRQUFBLElBQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFBO0tBQzNCO0FBQ0QsSUFBQSxtQkFBbUIsQ0FBQyxHQUFZLEVBQUE7UUFDNUIsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUM5QyxZQUFBLE1BQU0sWUFBWSxHQUFHLElBQUksb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDbkQsWUFBQSxZQUFZLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUMzQixZQUFBLE1BQU0sZUFBZSxHQUFHLElBQUksb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDdEQsWUFBQSxlQUFlLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUM5QixZQUFBLGVBQWUsQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFBOztBQUVyQyxZQUFBLEdBQUcsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQ3pCLE9BQU8sRUFDUCxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FDdkMsQ0FBQTtBQUNELFlBQUEsR0FBRyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FDekIsVUFBVSxFQUNWLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUM3QyxDQUFBOztBQUVELFlBQUEsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUc7QUFDM0IsZ0JBQUEsS0FBSyxFQUFFLFlBQVk7QUFDbkIsZ0JBQUEsUUFBUSxFQUFFLGVBQWU7YUFDNUIsQ0FBQTtBQUNKLFNBQUE7S0FDSjtBQUNELElBQUEscUJBQXFCLENBQUMsR0FBWSxFQUFBO1FBQzlCLElBQUksSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQzdDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQzdDLFlBQUEsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFBO0FBQzlCLFlBQUEsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFBO1lBRWpDLEdBQUcsQ0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQzVCLE9BQU8sRUFDUCxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUMzQyxDQUFBO1lBQ0QsR0FBRyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FDNUIsVUFBVSxFQUNWLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQ2pELENBQUE7WUFDRCxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3RDLFNBQUE7S0FDSjtBQUNELElBQUEseUJBQXlCLENBQUMsR0FBWSxFQUFFLE9BQUEsR0FBbUIsSUFBSSxFQUFBO1FBQzNELElBQUksT0FBTyxJQUFJLE9BQU8sR0FBRyxDQUFDLFlBQVksS0FBSyxXQUFXLEVBQUU7QUFDcEQsWUFBQSxHQUFHLENBQUMsWUFBWSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUE7QUFDM0IsWUFBQSxHQUFHLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQTtBQUNqQixZQUFBLEdBQUcsQ0FBQyxlQUFlLEdBQUcsRUFBRSxDQUFBO1lBQ3hCLEdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU8sS0FBSTtBQUNoQyxnQkFBQSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtBQUNqQyxvQkFBQSxHQUFHLENBQUMsTUFBTSxFQUFFLDhCQUE4QixFQUFFO3dCQUN4QyxHQUFHO3dCQUNILE1BQU07d0JBQ04sT0FBTztBQUNWLHFCQUFBLENBQUMsQ0FBQTtBQUNMLGlCQUFBO0FBQ0QsZ0JBQUEsTUFBTSxRQUFRLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFBO2dCQUNyQyxJQUFJLFFBQVEsS0FBSyxJQUFJLEVBQUU7b0JBQ25CLE9BQU8sR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBQ2hELGlCQUFBO0FBQU0scUJBQUE7QUFDSCxvQkFBQSxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNsQyxvQkFBQSxPQUFPLEdBQUcsQ0FBQTtBQUNiLGlCQUFBO0FBQ0wsYUFBQyxDQUFBO0FBQ0osU0FBQTthQUFNLElBQUksQ0FBQyxPQUFPLElBQUksT0FBTyxHQUFHLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtBQUM1RCxZQUFBLEdBQUcsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQTtZQUMzQixPQUFPLEdBQUcsQ0FBQyxZQUFZLENBQUE7WUFDdkIsT0FBTyxHQUFHLENBQUMsUUFBUSxDQUFBO1lBQ25CLE9BQU8sR0FBRyxDQUFDLGVBQWUsQ0FBQTtBQUM3QixTQUFBO0tBQ0o7QUFDSjs7QUN2UUQsTUFBTSxjQUFjLEdBQW1CO0FBQ25DLElBQUEsR0FBRyxFQUFFLFNBQVM7QUFDZCxJQUFBLE9BQU8sRUFBRSxnQkFBZ0I7Q0FDNUIsQ0FBQTtBQUNELE1BQU0sY0FBYyxHQUFtQjtBQUNuQyxJQUFBLEdBQUcsRUFBRSxTQUFTO0FBQ2QsSUFBQSxPQUFPLEVBQUUsUUFBUTtDQUNwQixDQUFBO0FBRUQsTUFBTSxjQUFjLEdBQW1CO0FBQ25DLElBQUEsR0FBRyxFQUFFLFNBQVM7QUFDZCxJQUFBLE9BQU8sRUFBRSxnQ0FBZ0M7Q0FDNUMsQ0FBQTtBQUVELE1BQU0sbUJBQW1CLEdBQW1CO0FBQ3hDLElBQUEsR0FBRyxFQUFFLGNBQWM7QUFDbkIsSUFBQSxPQUFPLEVBQUUsYUFBYTtDQUN6QixDQUFBO0FBRUQsTUFBTSxrQkFBa0IsR0FBbUI7QUFDdkMsSUFBQSxHQUFHLEVBQUUsYUFBYTtBQUNsQixJQUFBLE9BQU8sRUFBRSw0QkFBNEI7Q0FDeEMsQ0FBQTtBQUVELE1BQU0sa0JBQWtCLEdBQUcsQ0FBTyxFQUFVLEtBQXNCLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBO0FBQzlELElBQUEsT0FBT0UsYUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0FBQ3pCLENBQUMsQ0FBQSxDQUFBO0FBRUQsTUFBTSxzQkFBc0IsR0FBRyxDQUFPLElBQVksS0FBc0IsU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDcEUsSUFBQSxPQUFPQyx1QkFBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQTtBQUNsRCxDQUFDLENBQUEsQ0FBQTtBQUVELE1BQU0sZUFBZSxHQUFHO0FBQ3BCLElBQUEsTUFBTSxFQUFFO0FBQ0osUUFBQSxNQUFNLEVBQUU7QUFDSixZQUFBLE1BQU0sRUFBRSxNQUFNO1lBQ2QsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDO0FBQ2YsWUFBQSxHQUFHLEVBQUUsUUFBUTtBQUNiLFlBQUEsUUFBUSxFQUFFLEVBQUU7QUFDWixZQUFBLFdBQVcsRUFBRSxDQUFPLENBQUMsS0FBSSxTQUFBLENBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQTtBQUNyQixnQkFBQSxPQUFPLElBQUksQ0FBQTtBQUNmLGFBQUMsQ0FBQTtBQUNKLFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxPQUFPLEVBQUU7QUFDTCxRQUFBLE1BQU0sRUFBRTtBQUNKLFlBQUEsR0FBRyxFQUFFQyxlQUFJLENBQUMsSUFBSSxDQUNWLGVBQWUsRUFDZixhQUFhLEVBQ2IsVUFBVSxFQUNWLE9BQU8sRUFDUCxTQUFTLENBQ1o7QUFDRCxZQUFBLFFBQVEsRUFBRTtBQUNOLGdCQUFBLE9BQU8sRUFBRTtvQkFDTCxJQUFJLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQztBQUM3QixpQkFBQTtBQUNKLGFBQUE7QUFDRCxZQUFBLFdBQVcsRUFBRSxDQUFPLENBQUMsS0FBSyxTQUFBLENBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQSxFQUFBLE9BQUEsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBLEVBQUEsQ0FBQTtBQUN0RCxTQUFBO0FBQ0QsUUFBQSxLQUFLLEVBQUU7QUFDSCxZQUFBLEdBQUcsRUFBRSxTQUFTO0FBQ2QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsa0JBQWtCLENBQUM7QUFDN0IsaUJBQUE7QUFDSixhQUFBO0FBQ0QsWUFBQSxXQUFXLEVBQUUsQ0FBTyxDQUFDLEtBQUssU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUEsRUFBQSxPQUFBLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQSxFQUFBLENBQUE7QUFDMUQsU0FBQTtBQUNELFFBQUEsS0FBSyxFQUFFO0FBQ0gsWUFBQSxHQUFHLEVBQUVBLGVBQUksQ0FBQyxJQUFJLENBQ1YsSUFBSSxFQUNKLGVBQWUsRUFDZixpQkFBaUIsRUFDakIsYUFBYSxDQUNoQjtBQUNELFlBQUEsUUFBUSxFQUFFO0FBQ04sZ0JBQUEsT0FBTyxFQUFFO29CQUNMLElBQUksRUFBRSxDQUFDLGtCQUFrQixDQUFDO0FBQzdCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxNQUFNLEVBQUU7QUFDSixRQUFBLE1BQU0sRUFBRTtBQUNKLFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLGVBQWUsRUFDZixtQkFBbUIsRUFDbkIsVUFBVSxFQUNWLE9BQU8sRUFDUCxlQUFlLENBQ2xCO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDRCxRQUFBLEtBQUssRUFBRTtBQUNILFlBQUEsR0FBRyxFQUFFLGVBQWU7QUFDcEIsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQzFELFNBQUE7QUFDRCxRQUFBLEtBQUssRUFBRTtBQUNILFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLElBQUksRUFDSixxQkFBcUIsRUFDckIsUUFBUSxFQUNSLFFBQVEsRUFDUixhQUFhLEVBQ2IsWUFBWSxDQUNmO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxRQUFRLEVBQUU7QUFDTixRQUFBLE1BQU0sRUFBRTtBQUNKLFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLGVBQWUsRUFDZixjQUFjLEVBQ2QsVUFBVSxFQUNWLE9BQU8sRUFDUCxVQUFVLENBQ2I7QUFDRCxZQUFBLFFBQVEsRUFBRTtBQUNOLGdCQUFBLE9BQU8sRUFBRTtvQkFDTCxJQUFJLEVBQUUsQ0FBQyxZQUFZLENBQUM7QUFDdkIsaUJBQUE7QUFDSixhQUFBO0FBQ0QsWUFBQSxXQUFXLEVBQUUsQ0FBTyxDQUFDLEtBQUssU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUEsRUFBQSxPQUFBLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQSxFQUFBLENBQUE7QUFDdEQsU0FBQTtBQUNELFFBQUEsS0FBSyxFQUFFO0FBQ0gsWUFBQSxHQUFHLEVBQUUsa0JBQWtCO0FBQ3ZCLFlBQUEsUUFBUSxFQUFFO0FBQ04sZ0JBQUEsT0FBTyxFQUFFO29CQUNMLElBQUksRUFBRSxDQUFDLFlBQVksQ0FBQztBQUN2QixpQkFBQTtBQUNKLGFBQUE7QUFDRCxZQUFBLFdBQVcsRUFBRSxDQUFPLENBQUMsS0FBSyxTQUFBLENBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQSxFQUFBLE9BQUEsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBLEVBQUEsQ0FBQTtBQUMxRCxTQUFBO0FBQ0osS0FBQTtBQUNELElBQUEsSUFBSSxFQUFFO0FBQ0YsUUFBQSxNQUFNLEVBQUU7QUFDSixZQUFBLEdBQUcsRUFBRUEsZUFBSSxDQUFDLElBQUksQ0FDVixlQUFlLEVBQ2Ysb0JBQW9CLEVBQ3BCLFVBQVUsRUFDVixPQUFPLEVBQ1AsZ0JBQWdCLENBQ25CO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDRCxRQUFBLEtBQUssRUFBRTtBQUNILFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLElBQUksRUFDSixxQkFBcUIsRUFDckIsV0FBVyxFQUNYLE1BQU0sRUFDTixhQUFhLEVBQ2IsWUFBWSxDQUNmO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxLQUFLLEVBQUU7QUFDSCxRQUFBLE1BQU0sRUFBRTtBQUNKLFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLGVBQWUsRUFDZixtQkFBbUIsRUFDbkIsVUFBVSxFQUNWLE9BQU8sRUFDUCxlQUFlLENBQ2xCO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDRCxRQUFBLEtBQUssRUFBRTtBQUNILFlBQUEsR0FBRyxFQUFFLGVBQWU7QUFDcEIsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQzFELFNBQUE7QUFDRCxRQUFBLEtBQUssRUFBRTtBQUNILFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLElBQUksRUFDSixlQUFlLEVBQ2YsZUFBZSxFQUNmLGVBQWUsRUFDZixhQUFhLEVBQ2IsV0FBVyxDQUNkO0FBQ0QsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0FBQ3ZCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDSixLQUFBO0FBQ0QsSUFBQSxRQUFRLEVBQUU7QUFDTixRQUFBLE1BQU0sRUFBRTtBQUNKLFlBQUEsR0FBRyxFQUFFQSxlQUFJLENBQUMsSUFBSSxDQUNWLGVBQWUsRUFDZixjQUFjLEVBQ2QsVUFBVSxFQUNWLE9BQU8sRUFDUCxVQUFVLENBQ2I7QUFDRCxZQUFBLFFBQVEsRUFBRTtBQUNOLGdCQUFBLE9BQU8sRUFBRTtvQkFDTCxJQUFJLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQztBQUM1QixpQkFBQTtBQUNKLGFBQUE7QUFDRCxZQUFBLFdBQVcsRUFBRSxDQUFPLENBQUMsS0FBSyxTQUFBLENBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQSxFQUFBLE9BQUEsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBLEVBQUEsQ0FBQTtBQUN0RCxTQUFBO0FBQ0QsUUFBQSxLQUFLLEVBQUU7QUFDSCxZQUFBLEdBQUcsRUFBRSxVQUFVO0FBQ2YsWUFBQSxRQUFRLEVBQUU7QUFDTixnQkFBQSxPQUFPLEVBQUU7b0JBQ0wsSUFBSSxFQUFFLENBQUMsaUJBQWlCLENBQUM7QUFDNUIsaUJBQUE7QUFDSixhQUFBO0FBQ0QsWUFBQSxXQUFXLEVBQUUsQ0FBTyxDQUFDLEtBQUssU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUEsRUFBQSxPQUFBLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQSxFQUFBLENBQUE7QUFDMUQsU0FBQTtBQUNELFFBQUEsS0FBSyxFQUFFO0FBQ0gsWUFBQSxHQUFHLEVBQUVBLGVBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxVQUFVLEVBQUUsY0FBYyxDQUFDO0FBQ2pFLFlBQUEsUUFBUSxFQUFFO0FBQ04sZ0JBQUEsT0FBTyxFQUFFO29CQUNMLElBQUksRUFBRSxDQUFDLGlCQUFpQixDQUFDO0FBQzVCLGlCQUFBO0FBQ0osYUFBQTtBQUNELFlBQUEsV0FBVyxFQUFFLENBQU8sQ0FBQyxLQUFLLFNBQUEsQ0FBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBLEVBQUEsT0FBQSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUEsRUFBQSxDQUFBO0FBQ3RELFNBQUE7QUFDSixLQUFBO0NBQ2dFLENBQUE7QUFFckUsTUFBTSxzQkFBc0IsR0FBa0M7QUFDMUQsSUFBQSxJQUFJLEVBQUUsTUFBTTtBQUNaLElBQUEsSUFBSSxFQUFFLE1BQU07QUFDWixJQUFBLEdBQUcsRUFBRSxLQUFLO0FBQ1YsSUFBQSxJQUFJLEVBQUUsTUFBTTtBQUNaLElBQUEsS0FBSyxFQUFFLE9BQU87Q0FDakIsQ0FBQTtBQUVELE1BQU0sYUFBYSxHQUVmO0FBQ0EsSUFBQSxHQUFHLEVBQUU7QUFDRCxRQUFBLElBQUksRUFBRSxNQUFNO0FBQ1osUUFBQSxHQUFHLEVBQUUsU0FBUztBQUNkLFFBQUEsSUFBSSxFQUFFLFVBQVU7QUFDaEIsUUFBQSxLQUFLLEVBQUUsUUFBUTtBQUNsQixLQUFBO0FBQ0QsSUFBQSxHQUFHLEVBQUU7QUFDRCxRQUFBLElBQUksRUFBRSxTQUFTO0FBQ2xCLEtBQUE7Q0FDSjs7QUM3UkQsTUFBTSxRQUFRLEdBQUcsQ0FDYixHQUFXLEVBQ1gsR0FBYSxFQUNiLE9BQUEsR0FHSyxFQUFFLEtBQ1UsU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDakIsSUFBQSxNQUFNLE1BQU0sR0FBRyxDQUFPLElBQWMsS0FBcUIsU0FBQSxDQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDckQsUUFBQSxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsR0FBRyxLQUFJOztBQUN2QixZQUFBLE1BQU0sS0FBSyxHQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQTtBQUNqQyxZQUFBLE1BQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFBO1lBQy9DLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDaEMsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFOztnQkFFaEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUEsQ0FBQSxFQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQSxDQUFBLENBQUcsQ0FBQTtBQUM3QixhQUFBO1lBQ0QsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNsQixJQUFJLENBQUEsRUFBQSxHQUFBLE9BQU8sS0FBQSxJQUFBLElBQVAsT0FBTyxLQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQUEsQ0FBQSxHQUFQLE9BQU8sQ0FBRSxTQUFTLE1BQUksSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUEsS0FBSyxFQUFFO0FBQzdCLGdCQUFBLEdBQUcsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtBQUMxQyxhQUFBO0FBQ0QsWUFBQSxNQUFNLEtBQUssR0FBR0MsbUJBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN6QyxnQkFBQSxLQUFLLEVBQUUsUUFBUTtBQUNmLGdCQUFBLEtBQUssRUFBRSxJQUFJO0FBQ2QsYUFBQSxDQUFDLENBQUE7WUFDRixLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDLElBQUksS0FBSTtnQkFDdEIsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ2IsYUFBQyxDQUFDLENBQUE7WUFDRixVQUFVLENBQUMsTUFBSztnQkFDWixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDVixhQUFDLEVBQUUsQ0FBQSxFQUFBLEdBQUEsT0FBTyxLQUFBLElBQUEsSUFBUCxPQUFPLEtBQUEsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQVAsT0FBTyxDQUFFLE9BQU8sTUFBQSxJQUFBLElBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUEsR0FBSSxHQUFHLENBQUMsQ0FBQTtBQUMvQixTQUFDLENBQUMsQ0FBQTtBQUNOLEtBQUMsQ0FBQSxDQUFBO0lBQ0QsTUFBTSxNQUFNLEdBQUcsYUFBYSxDQUFBO0lBQzVCLElBQUksS0FBSyxHQUFHLEtBQUssQ0FBQTtJQUNqQixNQUFNLElBQUksR0FBRyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFJO1FBQ3pCLE1BQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDL0IsUUFBQSxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUNaLEtBQUssR0FBRyxJQUFJLENBQUE7WUFDWixRQUNJLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztnQkFDakIsa0JBQWtCLENBQUMsR0FBRyxDQUFDO2dCQUN2QixHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQ2pDO0FBQ0osU0FBQTtBQUFNLGFBQUE7QUFDSCxZQUFBLE9BQU8sR0FBRyxDQUFBO0FBQ2IsU0FBQTtBQUNMLEtBQUMsQ0FBQyxDQUFBO0lBQ0YsSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNSLFFBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUNqQixLQUFBO0FBQ0QsSUFBQSxPQUFPLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQzdCLENBQUMsQ0FBQTs7QUNwREQsTUFBTSxPQUFPLENBQUE7SUFHVCxXQUNXLENBQUEsSUFBWSxFQUNuQixVQUE2RCxFQUFBO1FBRHRELElBQUksQ0FBQSxJQUFBLEdBQUosSUFBSSxDQUFRO0FBTXZCLFFBQUEsSUFBQSxDQUFBLGVBQWUsR0FBRyxDQUNkLFFBQXlCLEtBSXpCOztZQUNBLE1BQU0sR0FBRyxHQUFHLEVBR1gsQ0FBQTtZQUNELElBQUksRUFBRSxHQUFtQixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1lBQ2hELEtBQUssTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3RCLE1BQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUNmLGdCQUFBLElBQUksTUFBMEIsQ0FBQTtBQUM5QixnQkFBQSxJQUFJLEdBQUcsRUFBRTtBQUNMLG9CQUFBLElBQUksRUFBQyxDQUFBLEVBQUEsR0FBQSxFQUFFLEtBQUYsSUFBQSxJQUFBLEVBQUUsS0FBRixLQUFBLENBQUEsR0FBQSxLQUFBLENBQUEsR0FBQSxFQUFFLENBQUUsUUFBUSxNQUFFLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxDQUFBLE9BQU8sQ0FBQSxFQUFFO3dCQUN4QixTQUFRO0FBQ1gscUJBQUE7QUFDRCxvQkFBQSxNQUFNLEdBQ0MsTUFBQSxDQUFBLE1BQUEsQ0FBQSxNQUFBLENBQUEsTUFBQSxDQUFBLEVBQUEsRUFBQSxFQUFFLENBQ0YsR0FBQyxNQUFBLEVBQUUsQ0FBQyxRQUFRLENBQUMsT0FBTyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxHQUFJLEVBQUUsRUFDaEMsQ0FBQTtBQUNKLGlCQUFBO0FBQU0scUJBQUE7b0JBQ0gsTUFBTSxHQUFHLEVBQUUsQ0FBQTtBQUNkLGlCQUFBO2dCQUNELElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRTtBQUNmLG9CQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzNCLGlCQUFBO2dCQUNELElBQUksTUFBTSxDQUFDLE9BQU8sRUFBRTtBQUNoQixvQkFBQSxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7QUFDbEQsaUJBQUE7QUFDRCxnQkFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDckIsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFO0FBQ2Isb0JBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBO0FBQy9DLGlCQUFBO0FBQ0QsZ0JBQUEsSUFBSSxHQUFHLEVBQUU7QUFDTCxvQkFBQSxHQUFHLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNyQixpQkFBQTtBQUFNLHFCQUFBO0FBQ0gsb0JBQUEsR0FBRyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7QUFDbEIsaUJBQUE7QUFDSixhQUFBO0FBQ0QsWUFBQSxPQUFPLEdBQUcsQ0FBQTtBQUNkLFNBQUMsQ0FBQTtBQTdDRyxRQUFBLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO0FBQ2hCLFFBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxVQUFVLENBQUE7S0FDN0I7QUE0Q0osQ0FBQTtBQUVELE1BQU0saUJBQWlCLEdBQUcsTUFBZ0I7SUFDdEMsTUFBTSxPQUFPLEdBQWMsRUFBRSxDQUFBO0lBQzdCLEtBQUssTUFBTSxJQUFJLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsRUFBRTtBQUM3QyxRQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDekQsS0FBQTtBQUNELElBQUEsT0FBTyxPQUFPLENBQUE7QUFDbEIsQ0FBQyxDQUFBO0FBRUQsTUFBTSxVQUFVLENBQUE7QUFHWixJQUFBLFdBQUEsR0FBQTtRQUdBLElBQXVCLENBQUEsdUJBQUEsR0FBRyxNQUEwQixTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDaEQsWUFBQSxJQUFJLENBQUMsZUFBZSxHQUFHLEVBQUUsQ0FBQTtBQUN6QixZQUFBLE1BQU0sT0FBTyxHQUFHLGlCQUFpQixFQUFFLENBQUE7QUFDbkMsWUFBQSxNQUFNQyxJQUFFLEdBQUdDLFdBQVEsRUFBRSxDQUFBO0FBQ3JCLFlBQUEsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFPLE9BQU8sS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDOUIsZ0JBQUEsTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsR0FBRyxPQUFPLENBQUE7QUFDbEMsZ0JBQUEsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDRCxJQUFFLENBQUMsQ0FBQTtnQkFDdEIsSUFDSSxPQUFPLEdBQUcsS0FBSyxXQUFXO0FBQzFCLG9CQUFBLEdBQUcsQ0FBQyxXQUFXO3FCQUNkLE1BQU0sR0FBRyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUM5QjtBQUNFLG9CQUFBLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ3JDLGlCQUFBO2FBQ0osQ0FBQSxDQUFDLENBQUE7QUFDTixTQUFDLENBQUEsQ0FBQTtRQUNELElBQVcsQ0FBQSxXQUFBLEdBQUcsTUFBZ0I7WUFDMUIsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUN2RCxTQUFDLENBQUE7QUFDRCxRQUFBLElBQUEsQ0FBQSxjQUFjLEdBQUcsQ0FDYixNQUFnQyxLQUNOO1lBQzFCLE1BQU0sR0FBRyxHQUE2QixFQUFFLENBQUE7WUFDeEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sS0FBSTtnQkFDbkMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQ0MsV0FBUSxFQUFFLENBQUMsQ0FBQTtnQkFDaEQsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFBO0FBQzdCLGdCQUFBLElBQUksT0FBTyxJQUFJLENBQUMsT0FBTyxLQUFLLFdBQVcsRUFBRTtvQkFDckMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQTtBQUNoRCxpQkFBQTtBQUNMLGFBQUMsQ0FBQyxDQUFBO1lBQ0YsT0FBWSxNQUFBLENBQUEsTUFBQSxDQUFBLE1BQUEsQ0FBQSxNQUFBLENBQUEsRUFBQSxFQUFBLEdBQUcsQ0FBSyxFQUFBLE1BQU0sQ0FBRSxDQUFBO0FBQ2hDLFNBQUMsQ0FBQTtBQWpDRyxRQUFBLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0tBQ3RCO0FBaUNKOztBQzFHRCxNQUFNLFNBQVUsU0FBUUMsaUJBQVEsQ0FBQTtJQUk1QixXQUFZLENBQUEsSUFBbUIsRUFBUyxHQUFXLEVBQUE7UUFDL0MsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRHlCLElBQUcsQ0FBQSxHQUFBLEdBQUgsR0FBRyxDQUFRO1FBSDVDLElBQUksQ0FBQSxJQUFBLEdBQWdCLE1BQU0sQ0FBQTtRQUs3QixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQTs7QUFFOUIsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUN6QixVQUFVLENBQUMsTUFBSztBQUNaLFlBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUE7U0FDN0IsRUFBRSxFQUFFLENBQUMsQ0FBQTtLQUNUO0lBQ0ssTUFBTSxHQUFBOztBQUNSLFlBQUEsTUFBTSxZQUFZLEdBQWE7Z0JBQzNCLGNBQWM7Z0JBQ2QsYUFBYTtBQUNiLGdCQUFBLHlCQUF5QjthQUM1QixDQUFBO1lBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQzdDLFlBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtZQUNwRCxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ25DLFlBQUEsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQTtTQUN2RCxDQUFBLENBQUE7QUFBQSxLQUFBO0lBQ0QsY0FBYyxHQUFBO1FBQ1YsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFBO0tBQ3BCO0lBQ0QsV0FBVyxHQUFBO0FBQ1AsUUFBQSxPQUFPLGlCQUFpQixDQUFBO0tBQzNCO0FBQ0osQ0FBQTtBQUVELE1BQU0sYUFBYyxTQUFRQSxpQkFBUSxDQUFBO0lBR2hDLFdBQVksQ0FBQSxJQUFtQixFQUFTLEdBQVcsRUFBQTtRQUMvQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7UUFEeUIsSUFBRyxDQUFBLEdBQUEsR0FBSCxHQUFHLENBQVE7UUFGNUMsSUFBSSxDQUFBLElBQUEsR0FBZ0IsWUFBWSxDQUFBO1FBSW5DLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFBOztBQUU5QixRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFBO1FBQ3pCLFVBQVUsQ0FBQyxNQUFLO0FBQ1osWUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtTQUM3QixFQUFFLEVBQUUsQ0FBQyxDQUFBO0tBQ1Q7SUFDSyxNQUFNLEdBQUE7Ozs7WUFFUixJQUFJOztBQUVBLGdCQUFBLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFVLENBQUE7Z0JBQzNCLElBQUksR0FBRyxDQUFDLFlBQVksSUFBSSxHQUFHLENBQUMsWUFBWSxDQUFDLFVBQVU7QUFDL0Msb0JBQUEsR0FBRyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEVBQUU7O0FBRXhDLG9CQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQTtvQkFDckQsTUFBTSxXQUFXLENBQUMsWUFBWSxDQUFDO0FBQzNCLHdCQUFBLElBQUksRUFBRSxTQUFTO0FBQ2Ysd0JBQUEsS0FBSyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDM0IscUJBQUEsQ0FBQyxDQUFBOztvQkFHRixJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDN0Msb0JBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQTtvQkFDbEIsT0FBTTtBQUNULGlCQUFBO0FBQ0osYUFBQTtBQUFDLFlBQUEsT0FBTyxLQUFLLEVBQUU7O2dCQUVaLElBQUk7QUFDQSxvQkFBQSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBVSxDQUFBO0FBQzNCLG9CQUFBLElBQUksTUFBQSxDQUFBLEVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxDQUFBLEVBQUEsR0FBQSxHQUFHLENBQUMsT0FBTyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxDQUFFLE9BQU8sTUFBQSxJQUFBLElBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUEsQ0FBRyxnQkFBZ0IsQ0FBQyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxDQUFFLFFBQVEsTUFBQSxJQUFBLElBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUEsQ0FBRSxTQUFTLEVBQUU7QUFDL0Qsd0JBQUEsR0FBRyxDQUFDLE1BQU0sRUFBRSxxRUFBcUUsRUFBRSxLQUFLLENBQUMsQ0FBQTtBQUM1RixxQkFBQTtBQUNKLGlCQUFBO0FBQUMsZ0JBQUEsT0FBTyxRQUFRLEVBQUU7O0FBRWxCLGlCQUFBO0FBQ0osYUFBQTs7QUFHRCxZQUFBLE1BQU0sWUFBWSxHQUFhO2dCQUMzQixjQUFjO2dCQUNkLGFBQWE7Z0JBQ2IseUJBQXlCO2dCQUN6QixjQUFjO2FBQ2pCLENBQUE7WUFDRCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQzlDLFlBQUEsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO1lBQy9DLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTs7QUFFOUIsWUFBQSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSw4R0FBOEcsQ0FBQyxDQUFBO0FBQ3hJLFlBQUEsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsdUNBQXVDLENBQUMsQ0FBQTtBQUMvRCxZQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQTs7QUFDbEQsS0FBQTtJQUNELGNBQWMsR0FBQTtRQUNWLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQTtLQUNwQjtJQUNELFdBQVcsR0FBQTtBQUNQLFFBQUEsT0FBTyxxQkFBcUIsQ0FBQTtLQUMvQjtBQUNKLENBQUE7QUFFRCxNQUFNLE9BQU8sQ0FBQTtBQUNULElBQUEsV0FBQSxDQUFtQixNQUF5QixFQUFBO1FBQXpCLElBQU0sQ0FBQSxNQUFBLEdBQU4sTUFBTSxDQUFtQjtLQUFJO0FBQ3hDLElBQUEsVUFBVSxDQUFDLElBQVMsRUFBQTs7QUFDeEIsUUFBQSxPQUFPLE1BQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxHQUFJLEVBQUUsQ0FBQTtLQUMxQjtJQUNPLGFBQWEsR0FBQTs7QUFDakIsUUFBQSxNQUFNLE9BQU8sR0FBRyxDQUFBLEVBQUEsR0FBQSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxZQUFZLE1BQUksSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUEsRUFBRSxDQUFBO1FBQ3ZELE1BQU0sUUFBUSxHQUFjLEVBQUUsQ0FBQTtRQUM5QixJQUFJO0FBQ0EsWUFBQSxLQUFLLE1BQU0sR0FBRyxJQUFJLE9BQU8sRUFBRTtBQUN2QixnQkFBQSxJQUNJLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksRUFDNUQ7QUFDRSxvQkFBQSxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3JCLGlCQUFBO0FBQ0osYUFBQTtBQUNKLFNBQUE7QUFBQyxRQUFBLE9BQU8sR0FBRyxFQUFFO0FBQ1YsWUFBQSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtnQkFDaEMsR0FBRyxDQUFDLE9BQU8sRUFBRSx5QkFBeUIsRUFBRSxDQUFHLEVBQUEsR0FBRyxDQUFFLENBQUEsQ0FBQyxDQUFBO0FBQ3BELGFBQUE7QUFDSixTQUFBO0FBQ0QsUUFBQSxPQUFPLFFBQVEsQ0FBQTtLQUNsQjtBQUNLLElBQUEsVUFBVSxDQUNaLEdBQVcsRUFDWCxJQUFjLEVBQ2QsVUFJSSxFQUFFLEVBQUE7OztZQUVOLE1BQU0sWUFBWSxHQUFHLE1BQWE7QUFDOUIsZ0JBQUEsTUFBTSxPQUFPLEdBQ1QsT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVc7QUFDbkMsc0JBQUUsS0FBSztBQUNQLHNCQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUE7Z0JBQzFCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQzFDLE9BQU8sS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLE9BQU87aUJBQ3RDLENBQUE7QUFDRCxnQkFBQSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDaEMsYUFBQyxDQUFBO1lBQ0QsSUFBSSxFQUFFLEdBQVcsU0FBUyxDQUFBOztBQUUxQixZQUFBLElBQUksT0FBTyxPQUFPLENBQUMsUUFBUSxLQUFLLFdBQVcsSUFBSSxJQUFJLEtBQUssUUFBUSxDQUFDLEdBQUcsRUFBRTtnQkFDbEUsRUFBRSxHQUFHLFlBQVksRUFBRSxDQUFBO0FBQ3RCLGFBQUE7QUFBTSxpQkFBQTtBQUNILGdCQUFBLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUNwQyxnQkFBQSxJQUFJLEdBQUcsR0FDSCxDQUFBLEVBQUEsR0FBQSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxJQUFJLEtBQUssUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxHQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxJQUFJLEtBQUssUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3JELGdCQUFBLEVBQUUsR0FBRyxDQUFBLEVBQUEsR0FBQSxHQUFHLEtBQUEsSUFBQSxJQUFILEdBQUcsS0FBQSxLQUFBLENBQUEsR0FBQSxLQUFBLENBQUEsR0FBSCxHQUFHLENBQUUsTUFBTSxNQUFBLElBQUEsSUFBQSxFQUFBLEtBQUEsS0FBQSxDQUFBLEdBQUEsRUFBQSxHQUFJLFlBQVksRUFBRSxDQUFBO0FBQ3JDLGFBQUE7WUFDRCxPQUFPLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLEtBQUEsSUFBQSxJQUFQLE9BQU8sS0FBQSxLQUFBLENBQUEsR0FBQSxLQUFBLENBQUEsR0FBUCxPQUFPLENBQUUsS0FBSyxFQUFFLE9BQU8sS0FBQSxJQUFBLElBQVAsT0FBTyxLQUFBLEtBQUEsQ0FBQSxHQUFBLEtBQUEsQ0FBQSxHQUFQLE9BQU8sQ0FBRSxZQUFZLENBQUMsQ0FBQTs7QUFDckYsS0FBQTtJQUNLLFVBQVUsQ0FDWixNQUFjLEVBQ2QsR0FBVyxFQUNYLElBQWMsRUFDZCxLQUFpQixHQUFBLElBQUksRUFDckIsWUFBQSxHQUF3QixLQUFLLEVBQUE7OztBQUU3QixZQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDMUQsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO0FBQ2YsZ0JBQUEsT0FBTyxJQUFJLENBQUE7QUFDZCxhQUFBO0FBQU0saUJBQUE7Z0JBQ0gsTUFBTSxJQUFJLEdBQUcsWUFBWSxHQUFHLElBQUksYUFBYSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUE7QUFDbkYsZ0JBQUEsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFBO2dCQUNyQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUM5QyxDQUFDLEdBQUcsS0FBSyxHQUFHLENBQUMsTUFBTSxLQUFLLE1BQU0sQ0FDakMsQ0FBQTtBQUNELGdCQUFBLElBQUksT0FBTyxHQUFHLEtBQUssV0FBVyxFQUFFO0FBQzVCLG9CQUFBLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFBOztvQkFFYixHQUFHLENBQUMsSUFBSSxHQUFHLENBQUEsRUFBQSxHQUFBLEdBQUcsQ0FBQyxJQUFJLE1BQUksSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUEsSUFBSSxDQUFBO0FBQzlCLGlCQUFBO0FBQU0scUJBQUE7b0JBQ0gsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQzt3QkFDdEMsTUFBTTt3QkFDTixHQUFHO3dCQUNILElBQUk7QUFDUCxxQkFBQSxDQUFDLENBQUE7QUFDTCxpQkFBQTtBQUNELGdCQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTs7QUFFaEMsZ0JBQUEsSUFBSSxLQUFLLEVBQUU7b0JBQ1AsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUNoRCxpQkFBQTtBQUNELGdCQUFBLE9BQU8sTUFBTSxDQUFBO0FBQ2hCLGFBQUE7O0FBQ0osS0FBQTtBQUNLLElBQUEsbUJBQW1CLENBQ3JCLEdBQVcsRUFDWCxJQUFjLEVBQ2QsVUFHSSxFQUFFLEVBQUE7O0FBRU4sWUFBQSxPQUFPLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFBLE1BQUEsQ0FBQSxNQUFBLENBQUEsTUFBQSxDQUFBLE1BQUEsQ0FBQSxFQUFBLEVBQU8sT0FBTyxDQUFFLEVBQUEsRUFBQSxZQUFZLEVBQUUsSUFBSSxJQUFHLENBQUE7U0FDOUUsQ0FBQSxDQUFBO0FBQUEsS0FBQTtJQUNLLFdBQVcsR0FBQTs7QUFDYixZQUFBLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtZQUNwQyxNQUFNLFFBQVEsR0FBYyxFQUFFLENBQUE7QUFDOUIsWUFBQSxLQUFLLE1BQU0sR0FBRyxJQUFJLE9BQU8sRUFBRTtnQkFDdkIsSUFDSSxDQUFDLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FDbEIsR0FBRyxDQUFDLE1BQU0sRUFDVixHQUFHLENBQUMsR0FBRyxFQUNQLEdBQUcsQ0FBQyxJQUFJLEVBQ1IsS0FBSyxDQUNSLE1BQU0sSUFBSSxFQUNiO0FBQ0Usb0JBQUEsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUNyQixpQkFBQTtBQUNKLGFBQUE7WUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsUUFBUSxDQUFBO0FBQzVDLFlBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFBO1NBQ25DLENBQUEsQ0FBQTtBQUFBLEtBQUE7QUFDSjs7QUMvS0QsTUFBTSxnQkFBZ0IsR0FBbUI7SUFDckMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxHQUFHO0FBQzVCLElBQUEsTUFBTSxFQUFFLEVBQUU7QUFDVixJQUFBLGdCQUFnQixFQUFFLEVBQUU7QUFDcEIsSUFBQSxTQUFTLEVBQUUsS0FBSztBQUNoQixJQUFBLE9BQU8sRUFBRSxHQUFHO0FBQ1osSUFBQSxZQUFZLEVBQUUsRUFBRTtDQUNuQixDQUFBO0FBRW9CLE1BQUEsY0FDakIsU0FBUUMsZUFBTSxDQUFBO0lBUVIsTUFBTSxHQUFBOztZQUNSLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDakMsWUFBQSxNQUFNLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQTtBQUN6QixZQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxVQUFVLEVBQUUsQ0FBQTtBQUNoQyxZQUFBLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsRUFBRSxDQUFBO1lBQzdDLE1BQU0sWUFBWSxHQUFHLENBQ2pCLEdBQWUsRUFDZixjQUFzQixFQUN0QixPQUFBLEdBRUksRUFBRSxLQUNTLFNBQUEsQ0FBQSxJQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQTs7Z0JBQ2YsTUFBTSxHQUFHLEdBQUcsWUFBdUIsQ0FBQTtBQUNuQyxnQkFBQSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsTUFBaUIsQ0FBQTtnQkFDaEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFO29CQUN4QyxPQUFNO0FBQ1QsaUJBQUE7Z0JBQ0QsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUMzQyxnQkFBQSxJQUFJLE9BQU8sT0FBTyxLQUFLLFdBQVcsRUFBRTtvQkFDaEMsSUFBSSxHQUFHLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRTtBQUNoQyx3QkFBQSxPQUFNO0FBQ1QscUJBQUE7QUFBTSx5QkFBQTtBQUNILHdCQUFBLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO3dCQUMxQixVQUFVLENBQUMsTUFBSztBQUNaLDRCQUFBLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFBO3lCQUMvQixFQUFFLEVBQUUsQ0FBQyxDQUFBO0FBQ1QscUJBQUE7QUFDSixpQkFBQTtBQUNELGdCQUFBLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEdBQUcsR0FBRyxDQUFBO2dCQUMxRCxJQUFJLFFBQVEsR0FBa0IsTUFBTSxDQUFBO0FBQ3BDLGdCQUFBLElBQUksTUFBTSxFQUFFO29CQUNSLFFBQVEsR0FBRyxLQUFLLENBQUE7QUFDbkIsaUJBQUE7QUFBTSxxQkFBQSxJQUFJLE9BQU8sRUFBRTtvQkFDaEIsUUFBUSxHQUFHLE1BQU0sQ0FBQTtBQUNwQixpQkFBQTtBQUFNLHFCQUFBLElBQUksT0FBTyxFQUFFO29CQUNoQixRQUFRLEdBQUcsTUFBTSxDQUFBO0FBQ3BCLGlCQUFBO0FBQU0scUJBQUEsSUFBSSxRQUFRLEVBQUU7b0JBQ2pCLFFBQVEsR0FBRyxPQUFPLENBQUE7QUFDckIsaUJBQUE7O2dCQUVELE1BQU0sR0FBRyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDOUIsZ0JBQUEsTUFBTSxTQUFTLEdBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEtBQUk7b0JBQ3ZDLElBQUksRUFBRSxDQUFDLFlBQVksSUFBSSxNQUFNLElBQUksV0FBVyxDQUFDLFNBQVMsRUFBRTtBQUNwRCx3QkFBQSxPQUFPLEtBQUssQ0FBQTtBQUNmLHFCQUFBO0FBQU0seUJBQUE7QUFDSCx3QkFBQSxPQUFPLEVBQUUsQ0FBQyxRQUFRLEtBQUssUUFBUSxDQUFBO0FBQ2xDLHFCQUFBO0FBQ0wsaUJBQUMsQ0FBQyxDQUFBO0FBQ04sZ0JBQUEsTUFBTSxXQUFXLEdBQUcsQ0FBQSxFQUFBLEdBQUEsU0FBUyxLQUFBLElBQUEsSUFBVCxTQUFTLEtBQVQsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsU0FBUyxDQUFFLE9BQU8sbUNBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUE7Z0JBQ2hFLE1BQU0sUUFBUSxHQUNWLEVBQUUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEtBQUssUUFBUTtzQkFDM0IsUUFBUTtzQkFDUCxFQUFFLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFjLElBQUksU0FBUyxDQUFBO2dCQUNqRSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ3pDLGdCQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7QUFDekIsb0JBQUEsR0FBRyxDQUFDLE1BQU0sRUFBRSw0QkFBNEIsRUFBRTtBQUN0Qyx3QkFBQSxLQUFLLEVBQUU7NEJBQ0gsTUFBTTs0QkFDTixNQUFNOzRCQUNOLE9BQU87NEJBQ1AsT0FBTzs0QkFDUCxRQUFRO0FBQ1gseUJBQUE7d0JBQ0QsRUFBRTt3QkFDRixRQUFRO0FBQ1Isd0JBQUEsVUFBVSxFQUFFLEdBQUc7QUFDZix3QkFBQSxHQUFHLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHO0FBQ2hCLHdCQUFBLEdBQUcsRUFBRyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQWUsQ0FBQyxHQUFHO3dCQUNqQyxHQUFHO3dCQUNILFdBQVc7d0JBQ1gsUUFBUTt3QkFDUixHQUFHO0FBQ0gsd0JBQUEsY0FBYyxFQUFFLFNBQVM7QUFDNUIscUJBQUEsQ0FBQyxDQUFBO0FBQ0wsaUJBQUE7O0FBRUQsZ0JBQUEsSUFDSSxPQUFPLE9BQU8sQ0FBQyxhQUFhLElBQUksV0FBVztBQUMzQyxvQkFBQSxNQUFNLElBQUksT0FBTyxDQUFDLGFBQWEsRUFDakM7b0JBQ0UsT0FBTTtBQUNULGlCQUFBOztBQUVELGdCQUFBLElBQUksV0FBVyxLQUFLLGNBQWMsQ0FBQyxHQUFHLEVBQUU7b0JBQ3BDLEdBQUcsQ0FBQyxjQUFjLEVBQUUsQ0FBQTtvQkFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxFQUFFLFFBQVEsQ0FBQyxHQUFHLEVBQUU7QUFDeEMsd0JBQUEsS0FBSyxFQUFFLFNBQVMsS0FBQSxJQUFBLElBQVQsU0FBUyxLQUFULEtBQUEsQ0FBQSxHQUFBLEtBQUEsQ0FBQSxHQUFBLFNBQVMsQ0FBRSxXQUFXO3dCQUM3QixRQUFRO0FBQ1gscUJBQUEsQ0FBQyxDQUFBO29CQUNGLE9BQU07QUFDVCxpQkFBQTtBQUNELGdCQUFBLElBQUksV0FBVyxLQUFLLG1CQUFtQixDQUFDLEdBQUcsRUFBRTtvQkFDekMsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFBO29CQUNwQixJQUFJLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDLElBQUksRUFBRTtBQUN6Qyx3QkFBQSxLQUFLLEVBQUUsU0FBUyxLQUFBLElBQUEsSUFBVCxTQUFTLEtBQVQsS0FBQSxDQUFBLEdBQUEsS0FBQSxDQUFBLEdBQUEsU0FBUyxDQUFFLFdBQVc7d0JBQzdCLFFBQVE7QUFDWCxxQkFBQSxDQUFDLENBQUE7b0JBQ0YsT0FBTTtBQUNULGlCQUFBOztBQUVELGdCQUFBLElBQUksV0FBVyxLQUFLLGtCQUFrQixDQUFDLEdBQUcsRUFBRTtvQkFDeEMsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFBO29CQUNwQixJQUFJLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxRQUFRLENBQUMsR0FBRyxFQUFFO0FBQ2pELHdCQUFBLEtBQUssRUFBRSxTQUFTLEtBQUEsSUFBQSxJQUFULFNBQVMsS0FBVCxLQUFBLENBQUEsR0FBQSxLQUFBLENBQUEsR0FBQSxTQUFTLENBQUUsV0FBVzt3QkFDN0IsUUFBUTtBQUNYLHFCQUFBLENBQUMsQ0FBQTtvQkFDRixPQUFNO0FBQ1QsaUJBQUE7QUFDRCxnQkFBQSxJQUFJLE9BQU8sR0FBRyxLQUFLLFdBQVcsRUFBRTtvQkFDNUIsR0FBRyxDQUFDLGNBQWMsRUFBRSxDQUFBO29CQUNwQixNQUFNLElBQUksR0FBRyxNQUFNLFFBQVEsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFO0FBQ2xDLHdCQUFBLFNBQVMsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDbEMsd0JBQUEsT0FBTyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTztBQUNqQyxxQkFBQSxDQUFDLENBQUE7b0JBQ0YsSUFBSSxJQUFJLEtBQUssQ0FBQyxFQUFFO0FBQ1osd0JBQUEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtBQUN6Qiw0QkFBQSxHQUFHLENBQ0MsT0FBTyxFQUNQLGdCQUFnQixFQUNoQixDQUFBLHlCQUFBLEVBQTRCLElBQUksQ0FBUSxNQUFBLENBQUE7Z0NBQ3BDLENBQXdDLHFDQUFBLEVBQUEsV0FBVyxDQUFHLENBQUEsQ0FBQSxDQUM3RCxDQUFBO0FBQ0oseUJBQUE7QUFDRCx3QkFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3hCLHFCQUFBO0FBQ0osaUJBQUE7QUFBTSxxQkFBQTtBQUNILG9CQUFBLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDeEIsaUJBQUE7QUFDTCxhQUFDLENBQUEsQ0FBQTs7QUFFRCxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFBOztZQUVsRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3pDLFlBQUEsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLFVBQVUsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFBO0FBQzFELFlBQUEsTUFBTSxVQUFVLEdBQUcsQ0FBQyxHQUFZLEtBQUk7QUFDaEMsZ0JBQUEsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMseUJBQXlCLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFBO0FBQ3JELGdCQUFBLElBQUksQ0FBQyxXQUFXLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUE7Z0JBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLENBQUMsR0FBRyxLQUFJO0FBQ3hDLG9CQUFBLE9BQU8sWUFBWSxDQUFDLEdBQUcsRUFBRSwwQkFBMEIsRUFBRTt3QkFDakQsYUFBYSxFQUFFLFdBQVcsQ0FBQyxJQUFJO0FBQ2xDLHFCQUFBLENBQUMsQ0FBQTtBQUNOLGlCQUFDLENBQUMsQ0FBQTtnQkFDRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRSxDQUFDLEdBQUcsS0FBSTtBQUMzQyxvQkFBQSxPQUFPLFlBQVksQ0FBQyxHQUFHLEVBQUUsMEJBQTBCLEVBQUU7d0JBQ2pELGFBQWEsRUFBRSxXQUFXLENBQUMsU0FBUztBQUN2QyxxQkFBQSxDQUFDLENBQUE7QUFDTixpQkFBQyxDQUFDLENBQUE7QUFDTixhQUFDLENBQUE7WUFDRCxVQUFVLENBQUMsWUFBdUIsQ0FBQyxDQUFBO0FBQ25DLFlBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLEtBQUk7Z0JBQzdDLFVBQVUsQ0FBQyxHQUFjLENBQUMsQ0FBQTtBQUM5QixhQUFDLENBQUMsQ0FBQTtBQUNGLFlBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLGNBQWMsRUFBRSxDQUFDLEVBQUUsRUFBRSxHQUFHLEtBQUk7QUFDOUMsZ0JBQUEsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQWMsQ0FBQyxDQUFBO0FBQzFDLGFBQUMsQ0FBQyxDQUFBOztZQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxNQUFXLFNBQUEsQ0FBQSxJQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQTtBQUN4QyxnQkFBQSxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUE7QUFDakMsZ0JBQUEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsRUFBRTtvQkFDekIsR0FBRyxDQUFDLE1BQU0sRUFBRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFBO0FBQzVELGlCQUFBO2FBQ0osQ0FBQSxDQUFDLENBQUE7U0FDTCxDQUFBLENBQUE7QUFBQSxLQUFBO0lBQ0ssUUFBUSxHQUFBOztBQUNWLFlBQUEsSUFBSSxPQUFPLElBQUksQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO0FBQzFDLGdCQUFBLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSTtBQUN4RCxvQkFBQSxJQUFJLENBQUMsc0JBQXNCLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDcEMsaUJBQUMsQ0FBQyxDQUFBO2dCQUNGLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQTtnQkFDdkIsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFBO0FBQzNCLGFBQUE7U0FDSixDQUFBLENBQUE7QUFBQSxLQUFBO0lBQ0ssWUFBWSxHQUFBOztBQUNkLFlBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUN6QixFQUFFLEVBQ0YsZ0JBQWdCLEVBQ2hCLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUN4QixDQUFBO1NBQ0osQ0FBQSxDQUFBO0FBQUEsS0FBQTtJQUNLLFlBQVksR0FBQTs7QUFDZCxZQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3pCLEdBQUcsQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ2hELGFBQUE7WUFDRCxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1NBQ3JDLENBQUEsQ0FBQTtBQUFBLEtBQUE7QUFDRCxJQUFBLFdBQVcsQ0FBQyxHQUFXLEVBQUE7QUFDbkIsUUFBQSxJQUFJLEdBQUcsS0FBSyxjQUFjLENBQUMsR0FBRyxFQUFFO0FBQzVCLFlBQUEsT0FBTyxTQUFTLENBQUE7QUFDbkIsU0FBQTtBQUNELFFBQUEsSUFBSSxHQUFHLEtBQUssY0FBYyxDQUFDLEdBQUcsRUFBRTtBQUM1QixZQUFBLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQTtBQUMvQixTQUFBO0FBQ0QsUUFBQSxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUE7S0FDakU7QUFDRCxJQUFBLGlCQUFpQixDQUFDLEdBQVksRUFBQTtBQUMxQixRQUFBLElBQUksT0FBTyxJQUFJLENBQUMsV0FBVyxLQUFLLFdBQVcsRUFBRTtBQUN6QyxZQUFBLElBQUksQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUE7QUFDekQsU0FBQTtBQUNELFFBQUEsSUFBSSxPQUFPLElBQUksQ0FBQyxZQUFZLEtBQUssV0FBVyxFQUFFO0FBQzFDLFlBQUEsSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUMxQyxTQUFBO0tBQ0o7QUFDRCxJQUFBLHNCQUFzQixDQUFDLEdBQVcsRUFBQTtBQUM5QixRQUFBLElBQUksT0FBTyxJQUFJLENBQUMsWUFBWSxLQUFLLFdBQVcsRUFBRTtZQUMxQyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUM1QyxZQUFBLElBQUksT0FBTyxHQUFHLEtBQUssV0FBVyxFQUFFO0FBQzVCLGdCQUFBLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUM5QixhQUFBO0FBQ0osU0FBQTtLQUNKO0FBQ0osQ0FBQTtBQUVELE1BQU0sVUFBVyxTQUFRQyxjQUFLLENBQUE7SUFDMUIsV0FBWSxDQUFBLEdBQVEsRUFBUyxPQUFlLEVBQUE7UUFDeEMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFBO1FBRGUsSUFBTyxDQUFBLE9BQUEsR0FBUCxPQUFPLENBQVE7QUFFeEMsUUFBQSxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQTtLQUN6QjtJQUNELE1BQU0sR0FBQTtBQUNGLFFBQUEsSUFBSSxFQUFFLFNBQVMsRUFBRSxHQUFHLElBQUksQ0FBQTtBQUN4QixRQUFBLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0tBQ2xDO0lBQ0QsT0FBTyxHQUFBO0FBQ0gsUUFBQSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsSUFBSSxDQUFBO1FBQ3hCLFNBQVMsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtLQUNwQjtBQUNKLENBQUE7QUFFRCxNQUFNLFVBQVcsU0FBUUMseUJBQWdCLENBQUE7SUFHckMsV0FBWSxDQUFBLEdBQVEsRUFBUyxNQUF5QixFQUFBO0FBQ2xELFFBQUEsS0FBSyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQTtRQURPLElBQU0sQ0FBQSxNQUFBLEdBQU4sTUFBTSxDQUFtQjtBQUVsRCxRQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFBO1FBQ3BCLElBQUksQ0FBQyxxQkFBcUIsR0FBR0MsaUJBQVEsQ0FDakMsQ0FBTyxHQUFHLEtBQUksU0FBQSxDQUFBLElBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBOztZQUNWLElBQUk7Z0JBQ0EsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQTtBQUN0QyxnQkFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUE7Z0JBQ2hDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtBQUNqQixhQUFBO0FBQUMsWUFBQSxPQUFPLENBQUMsRUFBRTtBQUNSLGdCQUFBLElBQUksQ0FBQyxLQUFLLENBQ04sQ0FBQSxFQUFBLEdBQUEsQ0FBQSxFQUFBLEdBQUEsQ0FBQyxDQUFDLE9BQU8sTUFDTCxJQUFBLElBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUEsR0FBQSxDQUFDLENBQUMsUUFBUSxFQUFFLE1BQ1osSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUEsdUNBQXVDLENBQzlDLENBQUE7QUFDSixhQUFBO0FBQ0wsU0FBQyxDQUFBLEVBQ0QsSUFBSSxFQUNKLElBQUksQ0FDUCxDQUFBO1FBQ0QsSUFBSSxDQUFDLHFCQUFxQixHQUFHQSxpQkFBUSxDQUNqQyxDQUFPLEdBQUcsS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDVixZQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUM3QixZQUFBLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRTtBQUN2QixnQkFBQSxJQUFJLENBQUMsS0FBSyxDQUFDLHNDQUFzQyxDQUFDLENBQUE7QUFDckQsYUFBQTtBQUFNLGlCQUFBO2dCQUNILElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7QUFDdEMsZ0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFBO2dCQUNoQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDakIsYUFBQTtBQUNMLFNBQUMsQ0FBQSxFQUNELElBQUksRUFDSixJQUFJLENBQ1AsQ0FBQTtLQUNKO0FBQ0QsSUFBQSxLQUFLLENBQUMsR0FBVyxFQUFBO1FBQ2IsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtLQUN2QztJQUNELE9BQU8sR0FBQTtBQUNILFFBQUEsSUFBSSxFQUFFLFdBQVcsRUFBRSxHQUFHLElBQUksQ0FBQTtRQUMxQixXQUFXLENBQUMsS0FBSyxFQUFFLENBQUE7UUFDbkIsSUFBSUMsZ0JBQU8sQ0FBQyxXQUFXLENBQUM7YUFDbkIsT0FBTyxDQUFDLFNBQVMsQ0FBQzthQUNsQixPQUFPLENBQUMsMkNBQTJDLENBQUM7QUFDcEQsYUFBQSxXQUFXLENBQUMsQ0FBQyxFQUFFLEtBQUk7QUFDaEIsWUFBQSxNQUFNLFFBQVEsR0FBcUI7Z0JBQy9CLGNBQWM7Z0JBQ2QsbUJBQW1CO2dCQUNuQixjQUFjO2dCQUNkLGtCQUFrQjtnQkFDbEIsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUNWLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FDL0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUM5QixDQUNKLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFJO0FBQ1Isb0JBQUEsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQTtBQUNyQixpQkFBQyxDQUFDO2FBQ0wsQ0FBQTtZQUNELElBQUksT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQzVCLENBQUMsRUFBRSxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNyRCxDQUFBO0FBQ0QsWUFBQSxJQUFJLE9BQU8sS0FBSyxDQUFDLENBQUMsRUFBRTtBQUNoQixnQkFBQSxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDbkQsYUFBQTtBQUNELFlBQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSSxFQUFBLElBQUEsRUFBQSxDQUFBLENBQ25CLE9BQUEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUEsRUFBQSxHQUFBLENBQUMsQ0FBQyxPQUFPLE1BQUEsSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBLEVBQUEsQ0FDMUMsQ0FBQTtBQUNELFlBQUEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFPLENBQUMsS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7Z0JBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUE7QUFDakMsZ0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFBO2FBQ25DLENBQUEsQ0FBQyxDQUFBO0FBQ04sU0FBQyxDQUFDLENBQUE7UUFDTixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNuQixPQUFPLENBQUMsZUFBZSxDQUFDO2FBQ3hCLE9BQU8sQ0FBQyxpQ0FBaUMsQ0FBQztBQUMxQyxhQUFBLFdBQVcsQ0FBQyxDQUFDLElBQUksS0FDZCxJQUFJO2FBQ0MsY0FBYyxDQUFDLElBQUksQ0FBQztBQUNwQixhQUFBLFFBQVEsQ0FDTCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQ3ZEO0FBQ0EsYUFBQSxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQzVDLENBQUE7QUFDTCxRQUFBLE1BQU0sU0FBUyxHQUFHLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ3JDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQzthQUM1QixPQUFPLENBQUMsNkJBQTZCLENBQUM7QUFDdEMsYUFBQSxTQUFTLENBQUMsQ0FBQyxHQUFHLEtBQUk7QUFDZixZQUFBLEdBQUcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDeEIsWUFBQSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQU8sQ0FBQyxLQUFJLFNBQUEsQ0FBQSxJQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsS0FBQSxDQUFBLEVBQUEsYUFBQTtnQkFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDO0FBQzFDLG9CQUFBLEVBQUUsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO29CQUNuQixRQUFRLEVBQUUsUUFBUSxDQUFDLE9BQU87QUFDMUIsb0JBQUEsUUFBUSxFQUFFLE1BQU07QUFDaEIsb0JBQUEsV0FBVyxFQUFFLElBQUk7QUFDakIsb0JBQUEsWUFBWSxFQUFFLEtBQUs7QUFDdEIsaUJBQUEsQ0FBQyxDQUFBO0FBQ0YsZ0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFBO2dCQUNoQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUE7YUFDakIsQ0FBQSxDQUFDLENBQUE7QUFDTixTQUFDLENBQUMsQ0FBQTtBQUNOLFFBQUEsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQTtBQUN2QyxRQUFBLFdBQVcsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUE7UUFDOUMsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUE7QUFFdEQsUUFBQSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxLQUFJO1lBQ3BCLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDekMsWUFBQSxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSw2Q0FBNkMsQ0FBQyxDQUFBO1lBQ25FLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDMUMsWUFBQSxNQUFNLEVBQUUsR0FBRyxJQUFJQSxnQkFBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQzVCLFlBQUEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsS0FBSTs7QUFDbEIsZ0JBQUEsTUFBTSxRQUFRLEdBQXFCO29CQUMvQixjQUFjO29CQUNkLG1CQUFtQjtvQkFDbkIsY0FBYztvQkFDZCxrQkFBa0I7b0JBQ2xCLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FDVixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQy9CLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDOUIsQ0FDSixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSTtBQUNSLHdCQUFBLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUE7QUFDckIscUJBQUMsQ0FBQztvQkFDRixjQUFjO2lCQUNqQixDQUFBO0FBQ0QsZ0JBQUEsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSTs7QUFDbkIsb0JBQUEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUEsRUFBQSxHQUFBLENBQUMsQ0FBQyxPQUFPLE1BQUksSUFBQSxJQUFBLEVBQUEsS0FBQSxLQUFBLENBQUEsR0FBQSxFQUFBLEdBQUEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQzNDLGlCQUFDLENBQUMsQ0FBQTtBQUNGLGdCQUFBLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQSxFQUFBLEdBQUEsRUFBRSxDQUFDLE9BQU8sTUFBQSxJQUFBLElBQUEsRUFBQSxLQUFBLEtBQUEsQ0FBQSxHQUFBLEVBQUEsR0FBSSxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDN0MsZ0JBQUEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFPLE9BQU8sS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7QUFDMUIsb0JBQUEsSUFBSSxPQUFPLEtBQUssY0FBYyxDQUFDLEdBQUcsRUFBRTt3QkFDaEMsT0FBTyxHQUFHLFNBQVMsQ0FBQTtBQUN0QixxQkFBQTtvQkFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQ3RDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FDeEIsQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO0FBQ25CLG9CQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTtvQkFDaEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO2lCQUNqQixDQUFBLENBQUMsQ0FBQTtBQUNOLGFBQUMsQ0FBQyxDQUFBO0FBQ0YsWUFBQSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUFJO2dCQUNwQixNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsdUJBQXVCLENBQUMsQ0FBQTtBQUMzRCxnQkFBQSxNQUFNLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUNoQyxnQkFBQSxNQUFNLENBQUMsVUFBVSxDQUFDLDRDQUE0QyxDQUFDLENBQUE7QUFDL0QsZ0JBQUEsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFPLEdBQUcsS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7b0JBQzFCLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FDdEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUN4QixDQUFDLFlBQVksR0FBRyxHQUFHLENBQUE7QUFDcEIsb0JBQUEsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxDQUFBO2lCQUNuQyxDQUFBLENBQUMsQ0FBQTtBQUNOLGFBQUMsQ0FBQyxDQUFBO0FBQ0YsWUFBQSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxLQUFJO2dCQUNwQixNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLENBQUMsQ0FBQTtBQUM1RCxnQkFBQSxJQUNJLEVBQUUsQ0FBQyxPQUFPLEtBQUssY0FBYyxDQUFDLEdBQUc7QUFDakMsb0JBQUEsRUFBRSxDQUFDLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxHQUFHO0FBQ3RDLG9CQUFBLEVBQUUsQ0FBQyxPQUFPLEtBQUssa0JBQWtCLENBQUMsR0FBRyxFQUN2QztBQUNFLG9CQUFBLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDekIsb0JBQUEsTUFBTSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDbEMsaUJBQUE7QUFBTSxxQkFBQTtvQkFDSCxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDLENBQUE7QUFDcEQsb0JBQUEsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUN4QixvQkFBQSxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3pCLGlCQUFBO0FBQ0QsZ0JBQUEsTUFBTSxDQUFDLFVBQVUsQ0FDYiwyRUFBMkUsQ0FDOUUsQ0FBQTtBQUNELGdCQUFBLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBTyxHQUFHLEtBQUksU0FBQSxDQUFBLElBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBO29CQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQ3RDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FDeEIsQ0FBQyxXQUFXLEdBQUcsR0FBRyxDQUFBO0FBQ25CLG9CQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTtpQkFDbkMsQ0FBQSxDQUFDLENBQUE7QUFDTixhQUFDLENBQUMsQ0FBQTtBQUNGLFlBQUEsRUFBRSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsS0FBSTtBQUNsQixnQkFBQSxNQUFNLFFBQVEsR0FBRyxXQUFXLEVBQUUsQ0FBQTtnQkFDOUIsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFJO0FBQ3RDLG9CQUFBLEVBQUUsQ0FBQyxTQUFTLENBQ1IsQ0FBQyxFQUNELGdDQUNPLHNCQUFzQixDQUFBLEVBQ3RCLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQSxDQUM1QixDQUFDLENBQUMsQ0FDUCxDQUFBO0FBQ0wsaUJBQUMsQ0FBQyxDQUFBO0FBQ0YsZ0JBQUEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDeEIsZ0JBQUEsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFPLFFBQXVCLEtBQUksU0FBQSxDQUFBLElBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBO29CQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQ3RDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsQ0FDeEIsQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFBO0FBQ3JCLG9CQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTtpQkFDbkMsQ0FBQSxDQUFDLENBQUE7QUFDTixhQUFDLENBQUMsQ0FBQTtBQUNGLFlBQUEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsS0FBSTtBQUNqQixnQkFBQSxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQzNCLGdCQUFBLEdBQUcsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUE7QUFDM0IsZ0JBQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFPLENBQUMsS0FBSSxTQUFBLENBQUEsSUFBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLEtBQUEsQ0FBQSxFQUFBLGFBQUE7b0JBQ3BCLE1BQU0sR0FBRyxHQUNMLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FDM0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsS0FBSyxFQUFFLENBQUMsRUFBRSxDQUN4QixDQUFBO0FBQ0wsb0JBQUEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQTtBQUNwRCxvQkFBQSxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLENBQUE7b0JBQ2hDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtpQkFDakIsQ0FBQSxDQUFDLENBQUE7QUFDTixhQUFDLENBQUMsQ0FBQTtZQUNGLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUNoQixPQUFPLEVBQ1AsNENBQTRDLENBQy9DLENBQUE7QUFDRCxZQUFBLFdBQVcsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDNUIsWUFBQSxHQUFHLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUNqQyxTQUFDLENBQUMsQ0FBQTtRQUVGLElBQUlBLGdCQUFPLENBQUMsV0FBVyxDQUFDO2FBQ25CLE9BQU8sQ0FBQyxNQUFNLENBQUM7YUFDZixPQUFPLENBQUMseURBQXlELENBQUM7QUFDbEUsYUFBQSxTQUFTLENBQUMsQ0FBQyxNQUFNLEtBQUk7WUFDbEIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUMvQyxZQUFBLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBTyxHQUFHLEtBQUksU0FBQSxDQUFBLElBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxLQUFBLENBQUEsRUFBQSxhQUFBO2dCQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFBO0FBQ3BDLGdCQUFBLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsQ0FBQTtnQkFDaEMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO2FBQ2pCLENBQUEsQ0FBQyxDQUFBO0FBQ04sU0FBQyxDQUFDLENBQUE7UUFDTixJQUFJQSxnQkFBTyxDQUFDLFdBQVcsQ0FBQzthQUNuQixPQUFPLENBQUMsU0FBUyxDQUFDO0FBQ2xCLGFBQUEsT0FBTyxDQUFDLENBQUMsSUFBSSxLQUNWLElBQUk7YUFDQyxjQUFjLENBQUMsS0FBSyxDQUFDO2FBQ3JCLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDakQsYUFBQSxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQzVDLENBQUE7S0FDUjtJQUNELE9BQU8sR0FBQTtRQUNILElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtLQUNqQjtBQUNKOzs7OyJ9
